var Student = /** @class */ (function () {
    function Student(fName, mInitial, lName) {
        this.fName = fName;
        this.mInitial = mInitial;
        this.lName = lName;
        this.fullName = fName + " " + mInitial + " " + lName;
    }
    return Student;
}());
function greeter(std) {
    return "Hello :::" + std.fullName;
}
var user = new Student("Deepak", "Kumar", "Sharma");
document.body.textContent = greeter(user);
