function greeter(person) {
    return "Hello, " + person.firstName + " " + person.lastName;
}
var user = { firstName: "Deepak", lastName: "Sharma" };
document.body.textContent = greeter(user);
