function greeterWithType(person) {
    return "Hello, " + person;
}
var user = "My Dear";
document.body.textContent = greeterWithType(user);
