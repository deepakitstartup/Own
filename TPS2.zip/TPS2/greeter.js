function greeter(person) {
    return "Hello, " + person;
}
var user = "Deepak";
document.body.textContent = greeter(user);
