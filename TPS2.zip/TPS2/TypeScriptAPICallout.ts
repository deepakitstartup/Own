import * as request from 'request';

class TypeScriptAPICallout {

   /**
    * name
    */
  getAnimalDetailsFromHeroku()
    {
      console.log('Entered in method');
        request.get('https://th-apex-http-callout.herokuapp.com/animals',(response:any) => {
           
        console.log(response);
                });
              

                request
                .get('https://th-apex-http-callout.herokuapp.com/animals')
                .on('response', function(response) {
                  console.log(response);
                  console.log(response.statusCode) // 200
                  console.log(response.headers['content-type']) // 'image/png'
                });
    }

   

}


let  tCallout=new TypeScriptAPICallout();
tCallout.getAnimalDetailsFromHeroku(); 
