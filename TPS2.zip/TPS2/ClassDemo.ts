class Student
{
    fullName: String;
    constructor(public fName: String, public mInitial: String, public lName: String)
    {
        this.fullName=fName+" "+mInitial+" "+lName;
    }
}
    interface Person
    {
         firstName: string;
         lastName: string;
    }

    function greeter(std: Student)
    {
        return "Hello :::"+std.fullName;
    }
    let user=new Student("Deepak","Kumar","Sharma");
    document.body.textContent=greeter(user);


