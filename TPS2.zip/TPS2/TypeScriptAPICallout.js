"use strict";
exports.__esModule = true;
var request = require("request");
var TypeScriptAPICallout = /** @class */ (function () {
    function TypeScriptAPICallout() {
    }
    /**
     * name
     */
    TypeScriptAPICallout.prototype.getAnimalDetailsFromHeroku = function () {
        console.log('Entered in method');
        request.get('https://th-apex-http-callout.herokuapp.com/animals', function (response) {
            console.log(response);
        });
        request
            .get('https://th-apex-http-callout.herokuapp.com/animals')
            .on('response', function (response) {
            console.log(response.body);
            console.log(response.statusCode); // 200
            console.log(response.headers['content-type']); // 'image/png'
        });
    };
    return TypeScriptAPICallout;
}());
var tCallout = new TypeScriptAPICallout();
tCallout.getAnimalDetailsFromHeroku();
