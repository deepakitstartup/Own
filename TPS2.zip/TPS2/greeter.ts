function greeter(person)
{
    return "Hello, "+person;
}

let user="Deepak";
document.body.textContent=greeter(user);