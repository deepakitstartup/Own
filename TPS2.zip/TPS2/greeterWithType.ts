function greeterWithType(person: string)
{
    return "Hello, "+person;
}

let user="My Dear";
document.body.textContent=greeterWithType(user);