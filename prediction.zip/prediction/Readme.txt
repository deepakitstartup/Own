set PATH="%PATH%;C:\Python27;C:\Python27\Scripts"


set FLASK_APP=hello.py

set FLASK_ENV=development

