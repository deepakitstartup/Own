import { SfdxCommand, FlagsConfig } from '@salesforce/command';
import { AnyJson } from '@salesforce/ts-types';
export default class Run extends SfdxCommand {
    static description: string;
    protected static requiresUsername: boolean;
    protected static supportsDevhubUsername: boolean;
    protected static requiresProject: boolean;
    protected static varargs: boolean;
    private conn;
    private connectionFailures;
    private TIMEOUT;
    protected static flagsConfig: FlagsConfig;
    /** Main run routine */
    run(): Promise<AnyJson>;
    private switchParallelTesting;
    private runAllTests;
    private runFailedTests;
    private testRun;
    private saveReport;
    private getTestResults;
    private getFailedTests;
    private filterFailures;
    private updateTestResults;
}
