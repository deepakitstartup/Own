import { SfdxCommand, FlagsConfig } from '@salesforce/command';
export default class prestep extends SfdxCommand {
    protected static requiresUsername: boolean;
    protected static supportsDevhubUsername: boolean;
    protected static requiresProject: boolean;
    protected static varargs: boolean;
    private conn;
    private appC;
    protected static flagsConfig: FlagsConfig;
    run(): Promise<void>;
    private validate;
}
