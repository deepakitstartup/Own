import { Connection } from "@salesforce/core";

export class Bulk{

    private conn: Connection;
    
    constructor(conn: Connection){
        this.conn = conn;
    }

    public async load(apexType: string, operation: any, records: any[]){
        return new Promise(
        (resolve, reject) => {
          let job = this.conn.bulk.createJob(apexType, operation);
          let batch = job.createBatch();
          batch.execute(records);

          batch.on("error", function(batchInfo) { // fired when batch request is queued in server.
            reject(batchInfo);
          });
          batch.on("queue", function(batchInfo) { // fired when batch request is queued in server.
            batch.poll(1000 /* interval(ms) */, 20000 /* timeout(ms) */); // start polling
          });
          batch.on("response", function(rets) { // fired when batch finished and result retrieved
            resolve(rets);
          });
        }
      );
    }
}