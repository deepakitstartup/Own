import { ConfigFile } from '@salesforce/core';
const crypto = require("crypto");
const algorithm = "aes-192-cbc";
const iv = Buffer.alloc(16, 0); // Initialization vector.
const FILE_NAME = "unilever_alm_config.json";

export class Util {
    constructor() {
    }
    public async decryptKey(encryptedKey: string) {
        const config = await ConfigFile.create({
            isGlobal: true,
            filename: FILE_NAME
        });
        const passKey = config.get('PASSKEY').toString();
        const key = crypto.scryptSync(passKey, 'salt', 24);
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        let decryptedPwd: string = decipher.update(encryptedKey, 'hex', 'utf8');
        decryptedPwd += decipher.final('utf8');

        return decryptedPwd;
    }
}

