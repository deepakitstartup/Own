import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
//import { ApexExecuteCommand } from 'salesforce-alm/dist/commands/force/apex/execute'
//import { DataRecordCreateCommand } from 'salesforce-alm/dist/commands/force/data/record/create'
//import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { join } from 'path'
import * as fs from 'fs'
//import { set } from 'lodash'
//import * as simplegit from 'simple-git/promise'
import { promisify } from 'util'
const readFile = promisify(fs.readFile)

export default class prestep extends SfdxCommand {

    private static maxCount = 9;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private appC: Org

    protected static flagsConfig: FlagsConfig = {

        recordid: flags.string({
            char: 'r',
            required: true,
            description: 'Release record Id'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        prefix: flags.string({
            char: 'n',
            required: true,
            description: 'App Prefix goes here'
        }),

        verbose: flags.builtin()
    }

    public async run() {
        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        await this.validate()   
        
    }

    /*
    *@description: This method contains logic to fetch static resources and create Build Step(release component) 
    *              
    *              
    */
    private async buildSteps(){
        try {
            //Step 1: fetch static resources records from release
            let recordId : any = `${this.flags['recordid']}`
            let res: any = await this.conn.query(`SELECT Id,Name,SAJ_Component_Type__c,SAJ_Type__c,SAJ_Release__c,SAJ_Release__r.SAJ_Environment__c FROM SAJ_Release_Component__c where SAJ_Release__c='${recordId}' and SAJ_Component_Type__c='staticresources'`)
            let releaseRec: any = res.records[0]
            let recCount: any = res.records.length
            this.ux.log('successfully fetched release component details')
            this.ux.log('Release component count: '+res.records.length)

            if(recCount==0){
                this.ux.log('Release component records not found')
                process.exit(0)
            }

            //Step 2: Check the count of the build steps
            let step: any
            if(recCount > this.maxCount){

            }
            //check component type
            this.ux.log('Component Type: '+ releaseRec.SAJ_Type__c)
            if(releaseRec.SAJ_Type__c==='Apex' && releaseRec.SAJ_Reference__c){
                this.ux.log('Yes! It is an Apex Class')

                //Step 2: fetch Release Component Environment object
                let env: any= await this.conn.query(`SELECT Id,Name from SAJ_Release_Environment__c WHERE SAJ_Release__c='${releaseRec.SAJ_Release__c}' AND SAJ_Environment__c='${releaseRec.SAJ_Release__r.SAJ_Environment__c}' order by createddate desc`)
                
                if(env.records.length==0){
                    this.ux.log('Release Environment Id not found!!')
                    process.exit(0) //TODO: Need to confirm
                }
                
                env = env.records[0]
                this.ux.log('targetusername: '+this.flags.targetusername)
                this.ux.log('Release Environment Id: '+env.Id)

                //check if RCE record is already ; if RCE already exists then do not create new record else create new record
                let valString: any
                //res = await this.conn.query(`SELECT Id,Name,SAJ_Deployment_Status__c,SAJ_Exception__c,SAJ_Release_Component__c,SAJ_Release_Environment__c FROM SAJ_Release_Component_Environment__c where SAJ_Release_Component__c='${recordId}' and SAJ_Release_Environment__c='${env.Id}' order by createddate desc`)
                //if (res.records.length == 0) {                    
                    let name: any = `${releaseRec.Name}-${env.Name}`//TODO: Need to check the name
                    valString = `Name=${name} SAJ_Release_Component__c=${recordId} SAJ_Release_Environment__c=${env.Id} SAJ_Deployment_Status__c=InProgess`
                    DataRecordCreateCommand.id = 'force:apex:data:create'
                    let result: any = await DataRecordCreateCommand.run(['-s', 'SAJ_Release_Component_Environment__c', '-v', valString, '-u', this.conn.getUsername()])
                    this.ux.log('result: '+result)
                //}else{
                  //this.ux.log('Release Component Environment already exists!!')
                //}
                

                //Step 3: execute below command to get log details from target org
                let testRun: any 
                let path: any = `${join(process.cwd(), releaseRec.SAJ_Reference__c)}`
                this.ux.log('Class path: '+path)
                ApexExecuteCommand.id = 'force:apex:execute'                
                testRun = await ApexExecuteCommand.run(['-f', path, '--json'])
                //testRun = await ApexExecuteCommand.run(['-f', path, '--json','-u', this.flags.targetusername])
                this.ux.log('Apex execute result: '+testRun)
                
                //getting result in [object Object] format, hence doing stringify and taking status result
                let jsonString: any = JSON.stringify(testRun)
                testRun = jsonString.split(',')
                let compiled: any = testRun[0].split(':')[1]
                let status: any = testRun[2].split(':')[1]
                this.ux.log('compiled is: '+compiled);
                this.ux.log('status is: '+status);
                                
                //step 4: update Deployment status and Exception field of Release Environment record
                let relEnv: any = await this.conn.query(`SELECT Id,Name,SAJ_Deployment_Status__c,SAJ_Exception__c,SAJ_Release_Component__c,SAJ_Release_Environment__c FROM SAJ_Release_Component_Environment__c where SAJ_Release_Component__c='${recordId}' and SAJ_Release_Environment__c='${env.Id}' order by createddate desc`)
                this.ux.log('Release Environment Component details: '+relEnv.records[0].Id)
                
                if(compiled && status){                    
                    valString = `SAJ_Exception__c=${jsonString} SAJ_Deployment_Status__c=Success`                    
                }else{
                    valString = `SAJ_Exception__c=${jsonString} SAJ_Deployment_Status__c=Error`
                    this.ux.log('Something went wrong. Please check log ')
                }
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Release_Component_Environment__c', '-i', relEnv.records[0].Id, '-v', valString, '-u', this.conn.getUsername()])
            }else{
                this.ux.log('Ops! Not an Apex class file')
            }
        } catch (error) {
            this.ux.log('Inside Catch!')
            throw new SfdxError(error.message)
        }
    }

    private async validate() {
        try {
            let username: any = this.conn.getUsername()
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix

            let res: any = await this.conn.query(`select id from User where Username='${username}'`)
            let userId: any = res.records[0].Id
            res = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any
            if (res.records.length == 0) {
                throw new SfdxError(`Details for Prefix ${prefix} does not exit on SAJ_Project_Dev_Prefix__c`)
            } else {
                parId = res.records[0].Id
            }
            res = await this.conn.query(`select UserOrGroupId from SAJ_App__Share where ParentId='${parId}' and UserOrGroupId='${userId}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`${username} is not authorized to work on ProjectPrefix ${prefix}`)
            } else {
                this.ux.log(`${username} is authorized to work on ProjectPrefix ${prefix}`)
                this.ux.log(`Validation Step Passed!`)
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    

}