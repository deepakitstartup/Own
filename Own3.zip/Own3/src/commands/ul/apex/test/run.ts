import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { Messages, SfdxError, Connection } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { ApexTestReportCommand } from 'salesforce-alm/dist/commands/force/apex/test/report'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { DataRecordCreateCommand } from 'salesforce-alm/dist/commands/force/data/record/create'
import { ApexSettings } from '../../../../lib/settings/setting'
import { Bulk } from '../../../../lib/bulk/bulk'
import * as path from 'path'
import * as fs from 'fs'
import { promisify } from 'util'
import * as _ from 'lodash'
const readFile = promisify(fs.readFile)

// Initialize Messages with the current plugin directory
Messages.importMessagesDirectory(__dirname)

// Load the specific messages for this file
const messages = Messages.loadMessages('ul', 'run')

export default class Run extends SfdxCommand {

  public static description = messages.getMessage('commandDescription')
  // public static examples = ApexTestRunCommand.help
  // protected static flagsConfig: FlagsConfig = ApexTestRunCommand.flagsConfig
  protected static requiresUsername = true
  protected static supportsDevhubUsername = true
  protected static requiresProject = true
  protected static varargs = true
  private conn: Connection
  private connectionFailures: any[]
  private TIMEOUT: string = '3600'
  // private ECONNRESETS: number = 1

  protected static flagsConfig: FlagsConfig = {

    expath: flags.string({
      char: 'e',
      required: false,
      description: 'Path For The Exemption List'
    }),

    level: flags.string({
      char: 'l',
      required: false,
      description: 'Test Levels'
    }),

    retrytime: flags.number({
      char: 't',
      required: true,
      description: 'Ms to wait for a class before it is retried'
    }),

    retryinc: flags.number({
      char: 'i',
      required: true,
      description: 'Ms to add for serial'
    }),

    classnames: flags.string({
      char: 'n',
      required: false,
      description: `Classnames you're running if it isn't one of the Log Levels`
    }),

    verbose: flags.builtin()

  }

  /** Main run routine */
  public async run(): Promise<AnyJson> {
    // get SFDC connection for targetusername
    this.conn = this.org.getConnection()

    // check for timeout flag
    if (this.flags.wait) {
      this.TIMEOUT = this.flags.wait
    }

    // enable parallel testing
    await this.switchParallelTesting(false)

    let parTime = 0
    let id = setInterval(() => {
      parTime = parTime + 5000
    }, 5000)

    // run all tests to start
    this.ux.log(messages.getMessage(`runningParallelTests`))
    const allTestResults: any = await this.runAllTests()

    const allTestRunId: string = allTestResults.summary.testRunId
    this.ux.log(`\n## Printing Junit format for runAllTests()\n`)
    await this.saveReport(allTestRunId)

    this.ux.log(`## Time taken to Run Tests in Parallel is: ${parTime}ms`)
    clearInterval(id)

    // get failures from ApexTestQueueItem
    const queueitemFailures: any = await this.conn.query(`select id,ApexClass.Name from ApexTestQueueItem where ParentJobId='${allTestResults.summary.testRunId}' and status='Failed'`)
    if (queueitemFailures) {
      this.connectionFailures = queueitemFailures.records
    }

    // get failed test results
    const failedTests: string[] = this.getFailedTests(allTestResults)

    if (failedTests.length > 0) {

      // disable parallel testing
      await this.switchParallelTesting(true)

      // run failures
      this.ux.log(messages.getMessage(`runningSerialTests`))
      
      let serTime = 0
      let id = setInterval(() => {
        serTime = serTime + 5000
      }, 5000)

      const failedTestRunResults = await this.runFailedTests(failedTests)
      clearInterval(id)
      this.ux.log(`## Time taken to Run Tests in Parallel is: ${serTime}ms`)

      // update the test results in SFDC
      await this.updateTestResults(allTestResults, failedTestRunResults)

      // get the final results
      await this.getTestResults(allTestRunId)

    }

    return process.exit(0)
  }

  private async switchParallelTesting(value: boolean) {
    // switch parallel testing
    try {
      this.ux.log(messages.getMessage('settingParallelTesting', [!value]))
      let result: any = await new ApexSettings(this.conn).update('enableDisableParallelApexTesting', value)

      if (result.success) {
        this.ux.log(messages.getMessage('setParallelTestingSuccess', [!value]))
      } else {
        throw new SfdxError(messages.getMessage('setParallelTestingFailed', [JSON.stringify(result.errors)]))
      }
    } catch (error) {
      throw new SfdxError(error.message)
    }

  }

  //TODO: Move testing functions to separate module

  private async runAllTests(): Promise<AnyJson> {

    ApexTestRunCommand.id = 'force:apex:test:run'
    let testRun: any
    if (this.flags.level) {
      testRun = await ApexTestRunCommand.run(['-u', this.flags.targetusername, '--json', '-l', this.flags.level])
    } else {
      this.ux.log(`Running for Specific TestClassNames!`)
      testRun = await ApexTestRunCommand.run(['-u', this.flags.targetusername, '--json', '-n', this.flags.classnames])
    }
    let allTests: any = await this.testRun(testRun.testRunId, 0, 'ALL')

    return allTests
  }

  private async runFailedTests(failedTests: string[]): Promise<AnyJson> {

    ApexTestRunCommand.id = 'force:apex:test:run'
    let id: any = await ApexTestRunCommand.run(['-u', this.flags.targetusername, '-t', failedTests.join(), '--json'])
    let failedTestRunResults = await this.testRun(id.testRunId, this.flags.retryinc, 'FAIL')

    return failedTestRunResults
  }

  private async testRun(testRunId: string, ms: number, type: string): Promise<AnyJson> {

    try {
      let time = this.flags.retrytime + ms
      let skippedIds = []
      let flag = true

      DataRecordUpdateCommand.id = 'force:apex:data:update'
      DataRecordCreateCommand.id = 'force:apex:data:create'

      do {
        //currenttime-systemmodstamp>threshold
        let res: any = await this.conn.query(`select Id,ApexClassId,MethodName,RunTime,ApexClass.Name FROM ApexTestResult where AsyncApexJobId='${testRunId}' and RunTime>${time} and ApexTestResult.ApexClassId in (select ApexTestQueueItem.ApexClassId from ApexTestQueueItem where Status='Processing' and ParentJobId='${testRunId}')`)

        if (res.records.length > 0) {
          for (const record of res.records) {
            if (skippedIds.includes[record.ApexClassId]) {
              this.ux.log(`ApexClassId ${record.ApexClassId} for ${record.ApexClass.Name} has already been Aborted, and records on ApexTestResult have been updated!`)
            } else {
              this.ux.log(`Aborting ApexClassId ${record.ApexClassId} since ${record.ApexClass.Name}.${record.MethodName} has crossed it's Threshold of ${time} milliseconds!`)
              await DataRecordUpdateCommand.run(['-s', 'ApexTestQueueItem', '-w', `ParentJobId=${testRunId} ApexClassId=${record.ApexClassId}`, '-v', 'status=Aborted'])
              skippedIds.push(record.ApexClassId)
              // let resp = await this.conn.query(`select Id,ApexClass.Name,MethodName from ApexTestResult where AsyncApexJobId='${testRunId}' and ApexClassId='${record.ApexClassId}'`)
              // let rec: any
              // for (rec of resp.records) {
              //   this.ux.log(`Updating ${rec.ApexClass.Name}.${rec.MethodName} with Id ${rec.Id} as Fail with an error Message!`)
              //   await DataRecordUpdateCommand.run(['-s', 'ApexTestResult', '-i', rec.Id, '-v', `Outcome=Fail Message='Class Was Looping!'`])
              // }
              // this.ux.log('\n')
            }
          }
        }

        // await new Promise(r => setTimeout(r, 15000))
        // let resp: any = await this.conn.query(`select count() from ApexTestResult where AsyncApexJobId='${testRunId}' and Outcome not in ('Fail','Pass')`)
        // this.ux.log(resp)
        // if(res.count == 0){
        //   await DataRecordUpdateCommand.run(['-s','ApexTestRunResult','-w',`AsyncApexJobId=${testRunId}`,'-v',`Status=Completed`])
        // }
        
        await new Promise(r => setTimeout(r, 15000))
        let resp: any = await this.conn.query(`select Status FROM ApexTestRunResult where AsyncApexJobId='${testRunId}'`)
        if (resp.records[0].Status == 'Completed' || resp.records[0].Status == 'Failed') {
          this.ux.log(`Running All Tests for id ${testRunId} is done!`)
          flag = false
        } else if (resp.records[0].Status == 'Aborted') {
          throw new SfdxError(`This Particular ApexTestRun has been Aborted!`)
        }
      } while (flag)

      let testResults: any = await ApexTestReportCommand.run(['-w', this.TIMEOUT, '-i', testRunId, '-u', this.flags.targetusername, '--json'])
      return testResults

    } catch (error) {
      if (error.syscall == 'ECONNRESET') {
        throw new SfdxError(error.info)
      } else {
        throw new SfdxError(error.message)
      }

    }

  }

  private async saveReport(testRunId: any) {

    let testDir = path.join(process.cwd(), 'tests')
    let filePath = path.join(testDir, `test-result-${testRunId}-junit.xml`)

    if (fs.existsSync(filePath)) {
      this.ux.log(`Deleting ${filePath} to make updated report\n`)
      fs.unlinkSync(filePath)
    }

    if (!fs.existsSync(testDir)) {
      this.ux.log(`Creating Log Directory at: ${testDir}\n`)
      fs.mkdirSync(testDir)
    }

    ApexTestReportCommand.id = 'force:apex:test:report'
    await ApexTestReportCommand.run(['-w', this.TIMEOUT, '-i', testRunId, '-u', this.flags.targetusername, '-r', 'junit', '-d', testDir, '-c'])
    this.ux.log(`\n Report printed to ${filePath}\n`)
  }

  private async getTestResults(asyncJobId: string) {
    // TODO: respect flags from test run command
    ApexTestReportCommand.id = 'force:apex:test:report'
    let results = await ApexTestReportCommand.run(['-w', this.TIMEOUT, '-i', asyncJobId, '-u', this.flags.targetusername, '--json'])

    this.ux.log(`\n## Printing Junit Format for getTestResults()\n`)
    await this.saveReport(results.summary.testRunId)

    // let exPath = '/var/lib/jenkins/jobs/CTT2.0/jobs/ENT_ORG/jobs/sfdx-ul-plugins/workspace/TestClassExemptionFile_CTT.txt'

    if (results.summary.outcome == 'Failed') {

      if (fs.existsSync(this.flags.expath)) {
        // let exPath = this.flags["expath"]
        this.ux.log(`Reading Exemption List from ${this.flags.expath}`)
        let exemption: any = await readFile(this.flags.expath, 'utf-8')
        exemption = exemption.split(',')
        this.ux.log(`Exempted Test Classes are:\n`)
        this.ux.log(exemption)
        let fail = false

        for (const testResult of results.tests) {
          if (testResult.Outcome == 'Fail' && exemption.includes(testResult.FullName)) {
            fail = false
            this.ux.log(`${testResult.FullName} is skipped as it is in the Exemption List`)
          } else if (testResult.Outcome == 'Fail' && !exemption.includes(testResult.FullName)) {
            fail = true
            break
          }
        }

        if (fail) {
          this.ux.log(`Failed Test Execution with ${results.summary.failing} failed tests`)
          this.ux.log(`Classes have failed which weren't covered in the Exemption List`)
          this.ux.log(results.summary)
          return process.exit(1)
        } else {
          this.ux.log(`Current Test Class failures are covered in the Exemption List`)
          this.ux.log('Successful Test execution')
          this.ux.log(results.summary)
          return process.exit(0)
        }

      } else {
        this.ux.log(`Failed Test Execution with ${results.summary.failing} failed tests`)
        this.ux.log(results.summary)
        return process.exit(1)
      }
    } else {
      this.ux.log('Successful Test execution')
      this.ux.log(results.summary)
      return process.exit(0)
    }

  }

  private getFailedTests(testResults: any): string[] {

    // get failures from ApexTestResult
    const failures = this.filterFailures(testResults)

    // Add fullNames first
    failures.forEach(test => {
      if (!test.FullName) {
        const containerName = test.ApexClass.Name
        test.FullName = `${containerName ? `${containerName}.` : ''}${test.MethodName}`
      }
    })

    //make list of test methods
    let testMethods: string[] = failures.map(t => t.FullName)

    this.connectionFailures.forEach(f => {
      testMethods.push(f.ApexClass.Name)
    })

    return testMethods

  }

  private filterFailures(testResults: any): any {
    return testResults.tests.filter(test => test.Outcome !== 'Pass' && test.Outcome !== 'Skip')
  }

  private async updateTestResults(allTests: any, reRunTests: any) {

    // update full run test results with re-runs
    const originalFailures: any[] = this.filterFailures(allTests)

    let mergedTests: any[] = reRunTests.tests.map(t => {

      let failedTest = originalFailures.find(o => o.FullName == t.FullName)
      if (!failedTest) {
        // test failed to run
        failedTest = this.connectionFailures.find(f => f.ApexClass.Name == t.ApexClass.Name)
        failedTest.QueueItemId = failedTest.Id
        failedTest.AsyncApexJobId = failedTest.ParentJobId
      }

      let mergedTest: any = {
        Id: t.Id,
        QueueItemId: failedTest.QueueItemId,
        AsyncApexJobId: failedTest.AsyncApexJobId
      }

      if (!failedTest.RunTime) {
        mergedTest.RunTime = 0
      }

      return mergedTest
    })

    const bulk = new Bulk(this.conn)

    // update ApexTestResults
    await bulk.load('ApexTestResult', 'update', mergedTests)

    // delete original failures
    if (originalFailures && originalFailures.length > 0) {
      await bulk.load('ApexTestResult', 'delete', originalFailures)
    }

  }

}
