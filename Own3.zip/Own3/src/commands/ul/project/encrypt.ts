import { SfdxCommand, FlagsConfig, flags } from "@salesforce/command"
import { /* SfdxError, Connection, */ ConfigFile } from "@salesforce/core"
import { AnyJson } from "@salesforce/ts-types"
const crypto = require("crypto")
import { writeFile, readFile } from 'fs'
import { promisify } from 'util'
const writeFileA = promisify(writeFile)
const readFileA = promisify(readFile)
const algorithm = "aes-192-cbc"
const iv = Buffer.alloc(16, 0) // Initialization vector.
const FILE_NAME = "unilever_alm_config.json"
var randomstring = require("randomstring")
import { config } from "dotenv"
import { resolve, join } from "path"
config({ path: resolve(__dirname, "../../../../.env") })

export default class Encryption extends SfdxCommand {
  public static description = "create a custom config entry."
  public globalKey: string
  public globalValue: string
  public hidden: boolean
  public passkey: string

  public static examples = [
    `$ sfdx ul:project:encrypt -o SONAR_PASSWORD -e test@123 -h
            Key            Value       
           ─────────     ────────── 
        SONAR_PASSWORD    test@123 
        `
  ]

  protected static flagsConfig: FlagsConfig = {
    globalkey: flags.string({
      char: "o",
      required: false,
      description: "passing the global variable name"
    }),
    globalvalue: flags.string({
      char: "e",
      required: true,
      description: "passing the password"
    }),
    hidden: flags.boolean({
      char: "h",
      required: false,
      description: "passing the hidden/encrypted"
    }),


    verbose: flags.builtin()
  }

  public async run(): Promise<AnyJson> {

    await this.work()
    return process.exit(0)

  }

  private async work() {
    try {
      this.globalKey = this.flags.globalkey
      this.globalValue = this.flags.globalvalue
      this.hidden = this.flags.hidden || false
      const config = await ConfigFile.create({
        isGlobal: true,
        filename: FILE_NAME
      })
      this.passkey = config.has('PASSKEY') ? config.get('PASSKEY').toString() : randomstring.generate()

      if (!this.globalKey) {
        this.ux.log(`Actual Key: ${this.globalValue}  `)
        const key = crypto.scryptSync(this.passkey, "salt", 24)
        const cipher = crypto.createCipheriv(algorithm, key, iv)
        let encryptedKey = cipher.update(this.globalValue, "utf8", "hex")
        encryptedKey = `${encryptedKey}${cipher.final("hex")}`
        this.ux.log(`Encrypted Key: ${encryptedKey}`)
        return process.exit(0)
      }

      this.ux.log(`Key: ${this.globalKey} 
    Value : ${this.globalValue}  
    Encrypt: ${this.hidden}`)

      // Use the async `crypto.scrypt()` instead.
      await this.encrypt()
      // fs.readFile(".env", "utf8", readData)
      // Prints: e5f79c5915c02171eec6b212d5520d44480993d7d622a7c4c2da32f6efda0ffa
      await this.writeGlobal("PASSKEY", this.passkey)
      return process.exit(0)
    } catch (error) {

    }
  }

  private async encrypt() {
    let data: any = await readFileA(`${join(process.cwd(), '.env')}`, 'utf-8')

    if (this.hidden) {
      const key = crypto.scryptSync(this.passkey, "salt", 24)
      const cipher = crypto.createCipheriv(algorithm, key, iv)
      let encrypted = cipher.update(this.globalValue, "utf8", "hex")
      encrypted = `${encrypted}${cipher.final("hex")}`
      data = data.replace(/[,]/g, '\n').split('\n')
      for (const record of data) {
        let key = record.split('=')[0]
        if (key == this.globalKey) {
          this.ux.log(`Existing key found for ${key}`)
          const index = data.indexOf(record)
          data.splice(index, 1)
        }
      }
      data = data.join(',')
      data = data.replace(/[,]/g, '\n')
      data = `${data}\n${this.globalKey}=${encrypted}`
      await writeFileA(`${join(process.cwd(), '.env')}`, data, 'utf-8')
    } else {
      data = data.replace(/[,]/g, '\n').split('\n')
      for (const record of data) {
        let key = record.split('=')[0]
        if (key == this.globalKey) {
          this.ux.log(`Existing key found for ${key}`)
          const index = data.indexOf(record)
          data.splice(index, 1)
        }
      }
      data = data.join(',')
      data = data.replace(/[,]/g, '\n')
      data = `${data}\n${this.globalKey}=${this.globalValue}`
      await writeFileA(`${join(process.cwd(), '.env')}`, data, 'utf-8')
    }

  }

  private async writeGlobal(key, value) {
    const config = await ConfigFile.create({
      isGlobal: true,
      filename: FILE_NAME
    })
    config.set(key, value)
    await config.write()
    return process.exit(0)
  }
}
