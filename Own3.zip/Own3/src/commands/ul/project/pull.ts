import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { join } from 'path'
import * as fs from 'fs'
import * as simplegit from 'simple-git/promise'
import { promisify } from 'util'
const readFile = promisify(fs.readFile)


export default class Run extends SfdxCommand {

    //public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private appC: Org

    public static examples = [
        `$ sfdx ul:project:pull -n feature -v app-central 
        Pull the feature to the origin branch
        This command will always pull the feature branch to the local`
    ]


    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: true,
            description: 'Name of the feature'
        }),

        rebase: flags.boolean({
            char: 'r',
            required: false,
            description: 'This will fetch and rebase'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        const name: string = this.flags.name;
        const rebase: boolean = this.flags.rebase || false;
        this.ux.log(`name:  ${name} , rebase:  ${rebase} `)
        let branchName = await this.getFeatureName();
        this.ux.log(` Pulling changes to the "${branchName}" feature branch `);
        await this.fetchRemoteBranches();
        await this.pullFeaturebranch(branchName, rebase);
        return process.exit(0)
    }

    private async getFeatureName() {
        try {
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix
            let res: any = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any = res.records[0].Id
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='SAJ_Feature'`)
            let featureId = res.records[0].Id
            let recordName = `${prefix}-DEV-${this.flags['name']}`
            res = await this.conn.query(`select Name, SAJ_Branch_Name__c FROM SAJ_Release__c where Name='${recordName}' and RecordTypeId='${featureId}' and SAJ_Application__c='${parId}'`)
            return res.records[0].SAJ_Branch_Name__c
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async fetchRemoteBranches() {
        this.ux.log(` Fetching remote branches... `);
        const git = simplegit();
        return git.fetch()
            .then(() => git.branch(['-a']))
            .then(branches => branches.all
                .filter(name => name.indexOf('remotes/origin') > -1)
                .map(name => name.replace('remotes/origin/', ''))
            )
    }

    private async pullFeaturebranch(branchName, rebase) {
        const git = simplegit();
        this.ux.log(` Pulling changes to the "${branchName}" feature branch `);

        if (rebase) {
            // results in 'git pull origin master --rebase=true'
            return git.checkout(branchName)
            .then(() =>  git.pull('origin', branchName, { '--rebase': 'true' }))
        } else {
            // results in 'git pull origin master --no-rebase'
            return git.checkout(branchName)
            .then(() =>  git.pull('origin', branchName, { '--no-rebase': null }))
        }
            
    }

}