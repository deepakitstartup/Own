import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { join } from 'path'
import * as fs from 'fs'
import { set } from 'lodash'
import * as simplegit from 'simple-git/promise'
import { promisify } from 'util'
const readFile = promisify(fs.readFile)

export default class init extends SfdxCommand {

    //public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private appC: Org

    public static examples = [
        `$ sfdx project:init -n ALM -v app-central 
         Based on the App Central configuration set the App Prefix in the sfdx-config file so that all commands are in context of the App
         Also set the default org that hosts app central`
    ]

    protected static flagsConfig: FlagsConfig = {

        prefix: flags.string({
            char: 'n',
            required: true,
            description: 'App Prefix goes here'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        verbose: flags.builtin()
    }

    public async run() {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        await this.json()
        await this.indexUpdate()
        await this.validate()

    }

    private async json() {
        let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
        if (!fs.existsSync(jsonPath)) {
            throw new SfdxError(`${jsonPath} does not exist!`)
        } else {
            let json = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'))
            this.ux.log(`Updating Prefix and BranchName as '${this.flags['prefix']}' under the Plugins section`)
            set(json, 'plugins.prefix', this.flags.prefix)
            set(json, 'plugins.branch', this.flags.prefix)
            await simplegit().raw(['checkout',this.flags.prefix])
            await simplegit().raw(['pull','origin',this.flags.prefix])
            fs.writeFileSync(jsonPath, JSON.stringify(json, null, 2), 'utf-8')
        }
    }

    private async indexUpdate() {
        try {
            this.ux.log(`Omitting sfdx-project.json from Git Tracking`)
            await simplegit().raw(
                [
                    'update-index',
                    '--skip-worktree',
                    'sfdx-project.json'
                ]
            )
            await simplegit().raw(['ls-files'])
            // res = await exec(`${res} | findstr ^S`)
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    // Export this function - common
    private async validate() {
        try {
            let username: any = this.conn.getUsername()
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix

            let res: any = await this.conn.query(`select id from User where Username='${username}'`)
            let userId: any = res.records[0].Id
            res = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any
            if (res.records.length == 0) {
                throw new SfdxError(`Details for Prefix ${prefix} does not exit on SAJ_Project_Dev_Prefix__c`)
            } else {
                parId = res.records[0].Id
            }
            res = await this.conn.query(`select UserOrGroupId from SAJ_App__Share where ParentId='${parId}' and UserOrGroupId='${userId}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`${username} is not authorized to work on ProjectPrefix ${prefix}`)
            } else {
                this.ux.log(`${username} is authorized to work on ProjectPrefix ${prefix}`)
                this.ux.log(`Validation Step Passed!`)
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}