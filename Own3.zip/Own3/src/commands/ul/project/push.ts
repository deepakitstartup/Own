import { SfdxCommand, FlagsConfig, flags } from "@salesforce/command";
import { SfdxError, Connection, Org } from "@salesforce/core";
import { AnyJson } from "@salesforce/ts-types";
import { join } from "path";
import * as fs from "fs";
import * as simplegit from "simple-git/promise";
import { promisify } from "util";
const readFile = promisify(fs.readFile);

export default class Run extends SfdxCommand {
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private appC: Org
    private conn: Connection;

    public static examples = [
        `$ sfdx ul:project:push -n featurename -m message -v app-central
        pushes the feature on the repo.
        This command always pushes the feature to the Project branch. This will add all files and commit with the message and pushes to the feature branch`
    ];

    protected static flagsConfig: FlagsConfig = {
        name: flags.string({
            char: "n",
            required: true,
            description: "Name of the feature"
        }),
        
        message: flags.string({
            char: "m",
            required: false,
            description: "Type your commit message"
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),
        verbose: flags.builtin()
    };

    public async run(): Promise<AnyJson> {
        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        const name = this.flags.name;
        const message = this.flags.message || "pushing changes to remote";
        this.ux.log(` name:  ${name} , message:  ${message} `);
        let branchName = await this.featureName();
        this.ux.log(` Pushing changes to the "${branchName}" feature branch `);

        await this.addCommitAndPush(branchName, message)
        await this.sonarCheck(branchName)
        return process.exit(0);
    }

    private async featureName() {
        try {
            let jsonPath = `${join(process.cwd(), "sfdx-project.json")}`;
            let json: any = await readFile(jsonPath, "utf-8");
            json = JSON.parse(json);
            let prefix: any = json.plugins.prefix;
            let res: any = await this.conn.query(
                `select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`
            );
            let parId: any = res.records[0].Id;
            res = await this.conn.query(
                `SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='SAJ_Feature'`
            );
            let featureId = res.records[0].Id;
            let recordName = `${prefix}-DEV-${this.flags["name"]}`;
            res = await this.conn.query(
                `select Name, SAJ_Branch_Name__c FROM SAJ_Release__c where Name='${recordName}' and RecordTypeId='${featureId}' and SAJ_Application__c='${parId}'`
            );
            return res.records[0].SAJ_Branch_Name__c;
        } catch (error) {
            throw new SfdxError(error.message);
        }
    }
    private async addCommitAndPush(branchName, message) {
        try {
            const git = simplegit() 
            await git.add('.')
            let res : any = await git.commit(message)
            this.ux.log(res)

            this.ux.log(`Pushing changes to origin/${branchName}`)
            res = await git.push('origin', branchName)
            this.ux.log(res)
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async sonarCheck(branchName){
        try {
            let res: any
            this.ux.log(`Polling for Sonar Status`)
            do {
                await new Promise(r => setTimeout(r, 15000))
                res = await this.conn.query(`select SAJ_Sonar_Status__c from SAJ_Release__c where SAJ_Branch_Name__c='${branchName}'`)
                this.ux.log(`Sonar Status for ${branchName} is ${res.records[0].SAJ_Sonar_Status__c}`)
            } while (res.records[0].SAJ_Sonar_Status__c=='Not-Scanned' || res.records[0].SAJ_Sonar_Status__c=='In-Progress')
            this.ux.log(`${branchName} has finished scanning!`)
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }
}


