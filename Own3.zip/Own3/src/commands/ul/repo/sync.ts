import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { config } from "dotenv"
import { resolve, join } from "path"
import * as fs from 'fs'
config({ path: resolve(__dirname, "../../../../.env") })
import { Util } from '../../../lib/decrypt/decrypt_helper'
import { promisify } from 'util'
import Axios from 'axios'
import init from '../project/init'
import fCreate from '../feature/create'
import rCreate from '../build/create'
import rBuild from '../build/validate'
import fMerge from '../feature/merge'
const writeFile = promisify(fs.writeFile)
const readFile = promisify(fs.readFile)

export default class Create extends SfdxCommand {

    public static examples = ApexTestRunCommand.help
    protected static requiresUsername = true
    protected static supportsDevhubUsername = false
    protected static requiresProject = true
    protected static varargs = true
    private conn: Connection
    private appC: Org
    private sharedOrg: Org

    protected static flagsConfig: FlagsConfig = {

        number: flags.number({
            char: 'n',
            required: false,
            description: 'Numbers of PRs to create'
        }),

        prpath: flags.string({
            char: 'p',
            required: false,
            description: 'Path for Processed PR files'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        sharedorg: flags.string({
            char: 'e',
            description: `Org you're pulling the PR off`,
            required: false
        }),

        prefix: flags.string({
            char: 'x',
            description: 'The project prefix to Create PR sync records on'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        this.sharedOrg = await Org.create({ aliasOrUsername: this.flags.sharedorg })
        await this.getPR()

        return process.exit(0)
    }

    private async getPR() {
        try {
            let path = `${join(process.cwd(),this.flags.path || 'prs.txt')}`
            if(!fs.existsSync(path)){
                this.ux.log(`Processed PRs file does not exist! Writing to ${path}`)
                await writeFile(path,'','utf-8')
            }
            let processedPrs = await readFile(path, 'utf-8')
            const util = new Util()
            const decryptedPassword = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.PR_PASSWORD) : process.env.PR_PASSWORD
            let res = await Axios({
                url: `https://stash.sfdevops.unileverservices.com/rest/api/1.0/projects/CU/repos/sfdxmanifest/browse`,
                method: 'get',
                headers: { 'Content-Type': 'application/json' },
                auth: {
                    username: process.env.PR_EMAIL,
                    password: decryptedPassword
                }
            })

            let count = 0
            if (processedPrs.length == 0) {
                this.ux.log(`## No Prs have been built yet!`)
                this.ux.log(`## Grabbing the latest PR`)
                let prArray = []
                for (const PR of res.data.children.values) {
                    prArray.push(PR.path.toString)
                }
                for (const PR of prArray) {
                    await this.buildPR(PR)
                    count++
                    if (this.flags.number) {
                        if (count == this.flags.number) {
                            this.ux.log(`A PR count for ${this.flags.number} has been deployed`)
                            process.exit(0)
                        }
                    }
                }

            } else if (processedPrs.length == 4) {
                let prArray = []
                for (const PR of res.data.children.values) {
                    prArray.push(PR.path.toString)
                }
                let index = prArray.indexOf(processedPrs)
                if (index > -1) {
                    prArray.splice(index, 1)
                }
                for (const PR of prArray) {
                    await this.buildPR(PR)
                    count++
                    if (this.flags.number) {
                        if (count == this.flags.number) {
                            this.ux.log(`A PR count for ${this.flags.number} has been deployed`)
                            process.exit(0)
                        }
                    }
                }

            } else {
                let procPrArray = []
                procPrArray = processedPrs.split(',')

                let prArray = []
                for (const PR of res.data.children.values) {
                    prArray.push(PR.path.toString)
                }

                for (const processed of procPrArray) {
                    let index = prArray.indexOf(processed)
                    if (index > -1) {
                        prArray.splice(index, 1)
                    }
                }

                for (const PR of prArray) {
                    await this.buildPR(PR)
                    count++
                    if (this.flags.number) {
                        if (count == this.flags.number) {
                            this.ux.log(`A PR count for ${this.flags.number} has been deployed`)
                            process.exit(0)
                        }
                    }
                }
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }


    }

    private async buildPR(prNo: any) {
        try {
            if (this.flags.prefix != "SYS-EU") {
                throw new SfdxError(`You shouldn't be able to sync pipelines on prefix ${this.flags.prefix}`)
            }

            await init.run(['-n', this.flags.prefix , '-v', this.conn.getUsername()])
            this.ux.log(`## PR-${prNo} is to be built!`)
            await fCreate.run(['-n', prNo, '-r', `PR${prNo}`, '-v', this.conn.getUsername(), '-e', this.sharedOrg.getUsername()])
            await fMerge.run(['-n', prNo, '-m', `Changes for PR-${prNo}`, '-v', this.conn.getUsername(), '-e', this.sharedOrg.getUsername()])
            await rCreate.run(['-n', prNo, '-r', `PR${prNo}`, '-v', this.conn.getUsername(), '-e'])
            await rBuild.run(['-n', prNo, '-v', this.conn.getUsername()])

            this.ux.log(`Waiting 240s for the job to poll`)
            await new Promise(r => setTimeout(r, 240000))

            this.ux.log(`Waiting 25 seconds for the console link to be updated`)
            await new Promise(r => setTimeout(r, 25000))

            let res: any = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${this.flags.prefix}'`)
            let parId: any = res.records[0].Id
            let recordName = `${this.flags.prefix}-REL-${prNo}`
            res = await this.conn.query(`select SAJ_Jenkins_Build_Log__c from SAJ_Release__c where RecordType.Name='Build' and SAJ_Application__c='${parId}' and Name=${recordName}`)
            let val = res.records[0].SAJ_Jenkins_Build_Log__c.split('/')
            let pr = val[7]
            let buildNo = val[8]
            res = await Axios({
                url: `${process.env.JENKINS_URL}job/sfdx-eu-fixed/view/change-requests/job/${pr}/${buildNo}/api/json`,
                method: 'GET',
                auth: {
                    username: process.env.JENKINS_USERNAME,
                    password: process.env.JENKINS_PASSWORD
                },
                headers: { 'Content-Type': 'application/json' },
            })
            if (res.data.building) {
                this.ux.log(`This Job for PR-${prNo} is still currently building!`)
                let id = setInterval(async () => {
                    let res = await Axios({
                        url: `${process.env.JENKINS_URL}job/sfdx-eu-fixed/view/change-requests/job/${pr}/${buildNo}/api/json`,
                        method: 'GET',
                        auth: {
                            username: process.env.JENKINS_USERNAME,
                            password: process.env.JENKINS_PASSWORD
                        },
                        headers: { 'Content-Type': 'application/json' },
                    })
                    if (!res.data.building) {
                        this.ux.log(`This Job for PR-${prNo} is done building!`)
                        clearInterval(id)
                    }
                }, 150000)
            }

            res = await this.conn.query(`select SAJ_Build_Validated__c from SAJ_Release__c where RecordType.Name='Build' and SAJ_Application__c='${parId}' and Name=${recordName}`)
            if (res.records[0].SAJ_Build_Validated__c) {
                this.ux.log(`Building ${recordName} was successful!`)
            }else{
                throw new SfdxError(`Building ${recordName} was unsuccessful`)
            }

            let path = `${join(process.cwd(),this.flags.path || 'prs.txt')}`
            let processedPrs = await readFile(path, 'utf-8')
            if (processedPrs.length == 0) {
                processedPrs = prNo
            } else {
                processedPrs = `${processedPrs},${prNo}`
            }
            await writeFile(path, processedPrs, 'utf-8')
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }
}