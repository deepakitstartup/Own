import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command';
import { SfdxError, Org, Connection } from '@salesforce/core';
import { AnyJson } from '@salesforce/ts-types';
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run';
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { join } from 'path';
import * as fs from 'fs';
import { promisify } from 'util'
import Axios from 'axios'
import { config } from "dotenv"
import { resolve } from "path"
config({ path: resolve(__dirname, "../../../../.env") })
import { Util } from '../../../lib/decrypt/decrypt_helper';
const exec = promisify(require('child_process').exec)
const writeFile = promisify(fs.writeFile)
const readFile = promisify(fs.readFile)
export default class runSonar extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = false;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private appC: Org
    private conn: Connection;

    protected static flagsConfig: FlagsConfig = {

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        branch: flags.string({
            char: 'b',
            required: true,
            description: 'Branch That Sonar is being Checked against against'
        }),

        runsonar: flags.boolean({
            char: 's',
            description: 'If Sonar is being run'
        }),

        comments: flags.boolean({
            char: 'c',
            required: false,
            description: 'Comments for Critical/Major/Blocker, Open and Unopened Issues'
        }),

        quality: flags.boolean({
            char: 'q',
            required: false,
            description: 'Exits with Non-Zero Exit code if Quality Gates are not met'
        }),

        path: flags.string({
            char: 'p',
            required: false,
            description: 'Path for Sonar (if not added)'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()

        if (this.flags.runsonar) {
            await this.runSonar()
            await new Promise(r => setTimeout(r, 5000))
        }
        await this.getSonar()
        if (this.flags.comments) {
            await this.commentSonar()
        }
        if (this.flags.quality) {
            await this.checkQualSonar()
        }
        return true
    }

    private async runSonar() {
        try {
            let sonarprop: any = `${join(process.cwd(), 'sonar-project.properties')}`
            let branchArray: any = this.flags.branch.split('-')
            let sonarstring: any = ``
            const util = new Util();
            const sonarPassword = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.SONAR_PASSWORD) : process.env.SONAR_PASSWORD;
            let src = 'force-app/main/default'

            if (branchArray[0] == 'PR') {
                this.ux.log(`Skipping the sonar scan on the PR`)
                process.exit(0)
            } else if (branchArray.length == 1 && branchArray[0] == 'CQA') {
                this.ux.log(`No Inclusions are Set`)
                sonarstring = `sonar.host.url=${process.env.SONAR_URL}\nsonar.sourceEncoding=UTF-8\nsonar.login=${process.env.SONAR_LOGIN}\nsonar.password=${sonarPassword}\nsonar.projectKey=${process.env.SONAR_KEY}\nsonar.branch.name=refs/remotes/origin/${this.flags.branch}\nsonar.sources=${src}/\nsonar.inclusions=**/*\nsonar.exclusions=${src}/permissionsets/**/*,${src}/profiles/**/*`
            } else if (branchArray.length == 1) {
                // Project branch
                sonarstring = `sonar.host.url=${process.env.SONAR_URL}\nsonar.sourceEncoding=UTF-8\nsonar.login=${process.env.SONAR_LOGIN}\nsonar.password=${sonarPassword}\nsonar.projectKey=${process.env.SONAR_KEY}\nsonar.branch.name=refs/remotes/origin/${this.flags.branch}\nsonar.branch.target=refs/remotes/origin/CQA\nsonar.sources=${src}/\nsonar.inclusions=**/${branchArray[0]}_*\nsonar.exclusions=${src}/permissionsets/**/*,${src}/profiles/**/*`
            } else {
                this.ux.log(`Updating Sonar Status as on ${this.flags.branch}`)
                DataRecordUpdateCommand.id = 'force:apex:data:update'
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Release__c', '-w', `SAJ_Branch_Name__c=${this.flags.branch}`, '-v', `SAJ_Sonar_Status__c='In-Progress'`, '-u', this.conn.getUsername()])
                sonarstring = `sonar.host.url=${process.env.SONAR_URL}\nsonar.sourceEncoding=UTF-8\nsonar.login=${process.env.SONAR_LOGIN}\nsonar.password=${sonarPassword}\nsonar.projectKey=${process.env.SONAR_KEY}\nsonar.branch.name=refs/remotes/origin/${this.flags.branch}\nsonar.branch.target=refs/remotes/origin/${branchArray[0]}\nsonar.sources=${src}/\nsonar.inclusions=**/${branchArray[0]}_*\nsonar.exclusions=${src}/permissionsets/**/*,${src}/profiles/**/*`
            }

            await writeFile(sonarprop, sonarstring, 'utf-8')
            this.ux.log(`Written Sonar Properties to ${sonarprop}!`)
            let sonarString: any = 'sonar-scanner'
            if (this.flags.path) {
                sonarString = `${this.flags.path}/sonar-scanner`
            }

            this.ux.startSpinner(`Performing a Sonar Scan Now!`)
            let resp: any = await exec(sonarString)
            this.ux.log(resp.stdout)
            this.ux.stopSpinner(`Sonar Scan Done!`)

            if(branchArray.length==1){
                process.exit(0)
            }

        } catch (error) {
            this.ux.log(error.message)
            process.exit(1)
        }
    }

    private async getSonar() {
        try {
            const util = new Util();
            const sonarToken = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.SONAR_TOKEN) : process.env.SONAR_TOKEN;
            let res: any = await Axios({
                url: `${process.env.SONAR_URL}/api/issues/search`,
                method: 'get',
                auth: {
                    username: sonarToken,
                    password: ''
                },
                params: {
                    componentKeys: process.env.SONAR_KEY,
                    branch: `refs/remotes/origin/${this.flags.branch}`,
                    severities: 'CRITICAL,MAJOR,BLOCKER',
                    statuses: 'OPEN,REOPENED'
                }
            })

            if (res.data.issues.length == 0) {
                this.ux.log(`There are no Issues of Serverities: Critical, Major, Blocker\nAnd Statuses: Open, Reopened on ${process.env.SONAR_KEY}\nYou're Good to go!`)
                this.ux.log(`Updating Sonar Status as Scanned Green for ${this.flags.branch}`)
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Release__c', '-w', `SAJ_Branch_Name__c=${this.flags.branch}`, '-v', `SAJ_Sonar_Status__c='Scanned Green'`, '-u', this.conn.getUsername()])
            } else {
                this.ux.log(`Updating Sonar Status as Scanned Red for ${this.flags.branch}`)
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Release__c', '-w', `SAJ_Branch_Name__c=${this.flags.branch}`, '-v', `SAJ_Sonar_Status__c='Scanned Red'`, '-u', this.conn.getUsername()])
                this.ux.log(res.data.issues)
                let issuesPath = `${join(process.cwd(), 'issues.json')}`
                let issuesObj: any = []
                for (const record of res.data.issues) {
                    issuesObj.push({ key: record.key, project: record.project, status: record.status, line: record.line, message: record.message, component: record.component, comment: "" })
                }
                if (!fs.existsSync(issuesPath)) {
                    await writeFile(issuesPath, JSON.stringify(issuesObj, null, 2), 'utf-8')
                    this.ux.log(`Work on the open Issues/add comments - saved to ${issuesPath}\n And run the command with the 'c' flag`)
                }
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async commentSonar() {
        try {
            let issuesPath = `${join(process.cwd(), 'issues.json')}`
            if (fs.existsSync(issuesPath)) {
                const util = new Util();
                const sonarToken = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.SONAR_TOKEN) : process.env.SONAR_TOKEN;
                let json: any = await readFile(issuesPath, 'utf-8')
                json = JSON.parse(json)
                for (const record of json) {
                    if (record.comment.length == 0) {
                        this.ux.log(`Key ${record.key} has an empty comment message!`)
                        process.exit(1)
                    }
                }
                for (const record of json) {
                    await Axios({
                        url: `${process.env.SONAR_URL}/api/issues/add_comment`,
                        method: 'post',
                        auth: {
                            username: sonarToken,
                            password: ''
                        },
                        params: {
                            issue: record.key,
                            text: record.comment
                        }
                    })

                }
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async checkQualSonar() {
        try {
            const util = new Util();
            const sonarToken = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.SONAR_TOKEN) : process.env.SONAR_TOKEN;
            let res: any = await Axios({
                url: `${process.env.SONAR_URL}/api/qualitygates/project_status`,
                method: 'post',
                auth: {
                    username: sonarToken,
                    password: ''
                },
                params: {
                    branch: `refs/remotes/origin/${this.flags.branch}`,
                    projectKey: process.env.SONAR_KEY
                }
            })
            if (res.data.projectStatus.status == 'OK') {
                this.ux.log(`The quality gates for Sonar on branch ${this.flags.branch} Have No errors!`)
                process.exit(0)
            } else {
                this.ux.log(`The quality gates for Sonar on branch ${this.flags.branch} Have failed!`)
                process.exit(1)
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }
}