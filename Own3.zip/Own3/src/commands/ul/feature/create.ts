import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { DataRecordCreateCommand } from 'salesforce-alm/dist/commands/force/data/record/create'
import { SourceRetrieveCommand } from 'salesforce-alm/dist/commands/force/source/retrieve'
import { MdapiDeployReportCommand } from 'salesforce-alm/dist/commands/force/mdapi/deploy/report'
import { join } from 'path'
import * as fs from 'fs'
import { set } from 'lodash'
import * as simplegit from 'simple-git/promise'
import { promisify } from 'util'
import Axios from 'axios'
import * as _ from 'lodash'
import { config } from "dotenv"
import { resolve } from "path"
config({ path: resolve(__dirname, "../../../../.env") })
import { Util } from '../../../lib/decrypt/decrypt_helper';
const writeFile = promisify(fs.writeFile)
const readFile = promisify(fs.readFile)
const find = require('find-process')


export default class Run extends SfdxCommand {

    protected static requiresUsername = true
    protected static supportsDevhubUsername = false
    protected static requiresProject = true
    private conn: Connection
    private appC: Org
    private sharedConn: Connection
    private sharedOrg: Org
    private deploymentId: string
    public static examples = [
        `$ sfdx ul:feature:create -n feature1 -r fyb1Test -v app-central

        This creates a feature on the repo and registers it in App Central for the App.
        This command always creates the feature from the Project branch.
        Technically it is possible to create a branch directly using git checkout but that is not recommended
        (as it won't create the necessary entries on app central)
        Feature are automatically prefixed with the App and Dev Prefix\n`,

        `$ sfdx ul:feature:create -n <PR-NO> -r prdescr -v app-central -e EU-CQA

        This creates a feature on the repo, based off a PR that's been deployed to a CQA environment.`
    ]

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: true,
            description: 'Name of the feature/PR'
        }),

        sharedorg: flags.string({
            char: 'e',
            description: `Org you're pulling the PR off`,
            required: false
        }),

        description: flags.string({
            char: 'r',
            required: false,
            description: 'Description of Feature/Jira Reference'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        force: flags.boolean({
            char: 'f',
            description: 'Force the create/append ID to feature if created'
        }),

        verbose: flags.builtin()
    }

    public async run() {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()

        if (!this.flags.sharedorg) {
            await this.validate()
        }

        let bName: any = await this.featureBranch()
        await this.featureRecord(bName)

    }

    private async featureBranch() {
        try {
            if (this.flags.sharedorg) {
                try {
                    const util = new Util()
                    const decryptedPassword = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.PR_PASSWORD) : process.env.PR_PASSWORD
                    await Axios({
                        url: `https://stash.sfdevops.unileverservices.com/rest/api/1.0/projects/CU/repos/sfdxmanifest/browse/${this.flags.name}`,
                        method: 'get',
                        headers: { 'Content-Type': 'application/json' },
                        auth: {
                            username: process.env.PR_EMAIL,
                            password: decryptedPassword
                        }
                    })
                } catch (error) {
                    if (error.response.data.errors[0].exceptionName == "com.atlassian.bitbucket.content.NoSuchPathException") {
                        throw new SfdxError(`PR-${this.flags.name} does not exist!`)
                    }
                }
                this.ux.log(`PR-${this.flags.name} exists!`)
            }

            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            if (!fs.existsSync(jsonPath)) {
                throw new SfdxError(`${jsonPath} does not exist!`)
            }
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let branchName = `${json.plugins.prefix}-${this.flags['name']}`
            this.ux.log(`Proposed Branchname is ${branchName}`)

            const git = simplegit()
            let res: any = await git.branch({})
            this.ux.log(`Current Branches are:`)
            this.ux.log(res.all)

            if (res.all.includes(branchName)) {
                if (this.flags.force) {
                    let i: number = 1
                    let origName = branchName
                    do {
                        let tag = (`0000${i}`).substr(-3)
                        branchName = `${origName}${tag}`
                        i++
                    } while (!res.all.includes(branchName))
                } else {
                    throw new SfdxError(`Branchname ${branchName} already exists! use the force`)
                }
            }

            if (this.flags.sharedorg) {
                this.sharedOrg = await Org.create({ aliasOrUsername: this.flags.sharedorg })
                this.sharedConn = this.sharedOrg.getConnection()
                const util = new Util()
                const decryptedPassword = (process.env.encrypted === 'true') ? await util.decryptKey(process.env.PR_PASSWORD) : process.env.PR_PASSWORD
                let res: any = await Axios({
                    url: `https://stash.sfdevops.unileverservices.com/projects/CU/repos/sfdxmanifest/browse/${this.flags.name}/deploymentId.txt`,
                    method: 'get',
                    params: 'raw',
                    auth: {
                        username: process.env.PR_EMAIL,
                        password: decryptedPassword
                    }
                })
                for (const rec of res.data.lines) {
                    this.deploymentId = `${rec.text}`
                }

                let object = {}
                res = await MdapiDeployReportCommand.run(['-i', this.deploymentId, '-u', this.sharedConn.getUsername(), '--json'])
                for (const record of res.details.componentSuccesses) {
                    if (record.changed == "true" && record.success == "true" && record.fullName != "package.xml") {
                        if (_.has(object, record.componentType)) {
                            object[record.componentType].push(record.fullName)
                        } else if (!_.has(object, record.componentType)) {
                            _.set(object, record.componentType, [])
                            object[record.componentType].push(record.fullName)
                        }
                    }
                }

                this.ux.log(`Retrieving the source for changed and successfully deployed components\n`)
                for (const property in object) {
                    if (object[property].length != 0) {
                        let str = ''
                        for (const val of object[property]) {
                            if (str.length == 0) {
                                str = `${property}:${val}`
                            } else {
                                str = `${str}, ${property}:${val}`
                            }
                        }
                        await SourceRetrieveCommand.run(['-m', str, '-u', this.sharedConn.getUsername()])
                    }
                }

            }

            await git.checkoutLocalBranch(branchName)
            this.ux.log(`Local Branch ${branchName} is created!`)
            this.ux.log(`Updating Branch under the Plugins Section`)
            set(json, 'plugins.branch', branchName)
            await writeFile(jsonPath, JSON.stringify(json, null, 2), 'utf-8')
            return branchName
        } catch (error) {
            if (error.message == `Cannot read property 'includes' of undefined`) {
                let res: any = await find('name', 'ul:repo:sync')
                if (res[0].cmd) {
                    this.ux.log(`Source cannot be retrieved on PR ${this.flags.name} and deploymentId ${this.deploymentId}`)
                    this.ux.log(`force:mdapi:deploy:report returns INVALID_CROSS_REFERENCE_KEY: invalid cross reference id`)
                    this.ux.log(`PR ${this.flags.name} can't be built`)
                    this.ux.log(`Killing process ${res[0].pid} - ${res[0].cmd}`)
                    process.kill(res[0].pid)
                }
            } else {
                throw new SfdxError(error.message)
            }

        }
    }

    private async featureRecord(bName) {
        try {
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix
            let res: any = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any = res.records[0].Id
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='SAJ_Feature'`)
            let featureId = res.records[0].Id
            let recordName = ''
            if (this.flags.sharedorg) {
                recordName = `${prefix}-PR-${this.flags.name}`
            } else {
                recordName = `${prefix}-DEV-${this.flags.name}`
            }
            res = await this.conn.query(`select Name FROM SAJ_Release__c where Name='${recordName}' and RecordTypeId='${featureId}' and SAJ_Application__c='${parId}'`)
            let featureName: any
            if (res.records.length == 0) {
                featureName = this.flags['name']
                this.ux.log(`${featureName} does not exist for prefix ${prefix}! Creating Feature Record`)
            } else {
                if (this.flags.force) {
                    featureName = `${this.flags['name']}001`
                } else {
                    throw new SfdxError(`${this.flags['name']} already exists for prefix ${prefix}! Use the Force`)
                }
            }
            DataRecordCreateCommand.id = 'force:apex:data:create'
            let valString = `Name=${recordName} SAJ_Application__c=${parId} RecordTypeId=${featureId} SAJ_Description__c='${this.flags.description}' SAJ_Status__c=New SAJ_Branch_Name__c=${bName}`
            this.ux.log(`Creating Feature record for Feature ${recordName}`)
            await DataRecordCreateCommand.run(['-s', 'SAJ_Release__C', '-v', valString, '-u', this.conn.getUsername()])
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }


    private async validate() {
        try {
            let username: any = this.conn.getUsername()
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix

            let res: any = await this.conn.query(`select id from User where Username='${username}'`)
            let userId: any = res.records[0].Id
            res = await this.conn.query(`select Id,Name from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any
            if (res.records.length == 0) {
                throw new SfdxError(`Details for Prefix ${prefix} does not exit on SAJ_Project_Dev_Prefix__c`)
            } else {
                parId = res.records[0].Id
            }
            res = await this.conn.query(`select UserOrGroupId from SAJ_App__Share where ParentId='${parId}' and UserOrGroupId='${userId}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`${username} is not authorized to work on ProjectPrefix ${prefix}`)
            } else {
                this.ux.log(`${username} is authorized to work on ProjectPrefix ${prefix}`)
                this.ux.log(`Validation Step Passed!`)
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}