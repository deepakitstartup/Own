import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command';
import { SfdxError, Connection, Org } from '@salesforce/core';
import { AnyJson } from '@salesforce/ts-types';
//import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run';
import { join } from 'path';
import * as fs from 'fs';
import { set } from 'lodash';
import * as simplegit from 'simple-git/promise';
import { promisify } from 'util'
const writeFile = promisify(fs.writeFile)
const readFile = promisify(fs.readFile)

export default class Run extends SfdxCommand {

    //public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private appC: Org
    public static examples = [
        `$ sfdx ul:feature:switch -n feature1 -v app-central
        Developer may have multiple features in progress - this command will let develops switch between them. 
        Similar to git checkout`
    ]

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: false,
            description: 'Name of the feature'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        await this.validate()
        let branchName = await this.getBranch()
        await this.switchBranch(branchName)

        return process.exit(0)
    }

    private async getBranch() {
        try {
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix

            let res: any = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any = res.records[0].Id

            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='SAJ_Feature'`)
            let featureId = res.records[0].Id
            let recordName = `${prefix}-DEV-${this.flags.name}`

            res = await this.conn.query(`select SAJ_Branch_Name__c FROM SAJ_Release__c where Name='${recordName}' and RecordTypeId='${featureId}' and SAJ_Application__c='${parId}'`)
            this.ux.log(`Assigned branchName for ${recordName} is ${res.records[0].SAJ_Branch_Name__c}`)
            return res.records[0].ALM_Branch_Name__c

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async switchBranch(branchName) {
        try {
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            if (!fs.existsSync(jsonPath)) {
                throw new SfdxError(`${jsonPath} does not exist!`)
            }
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)

            const git = simplegit()
            let res: any = await git.branch({})

            if (res.all.includes(branchName)) {
                this.ux.log(`Switching to Feature branch ${branchName}`)
                res = await simplegit().raw(['checkout', branchName])
                this.ux.log(res)
                set(json, 'plugins.branch', branchName)
                await writeFile(jsonPath, JSON.stringify(json, null, 2), 'utf-8')
            } else {
                throw new SfdxError(`Branch ${branchName} does not exist on your local! - Try Running ul:feature:create first`)
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async validate() {
        try {
            let username: any = this.conn.getUsername()
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix

            let res: any = await this.conn.query(`select id from User where Username='${username}'`)
            let userId: any = res.records[0].Id
            res = await this.conn.query(`select Id,Name from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any
            if (res.records.length == 0) {
                throw new SfdxError(`Details for Prefix ${prefix} does not exit on SAJ_Project_Dev_Prefix__c`)
            } else {
                parId = res.records[0].Id
            }
            res = await this.conn.query(`select UserOrGroupId from SAJ_App__Share where ParentId='${parId}' and UserOrGroupId='${userId}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`${username} is not authorized to work on ProjectPrefix ${prefix}`)
            } else {
                this.ux.log(`${username} is authorized to work on ProjectPrefix ${prefix}`)
                this.ux.log(`Validation Step Passed!`)
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}