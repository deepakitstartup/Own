import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { SourceRetrieveCommand } from 'salesforce-alm/dist/commands/force/source/retrieve'
import { join } from 'path'
import * as fs from 'fs'
import * as simplegit from 'simple-git/promise'
import { promisify } from 'util'
import runSonar from '../sonar/run'
import Diff from '../org/diffploy'
const readFile = promisify(fs.readFile)

export default class fMerge extends SfdxCommand {
    protected static requiresUsername = true
    protected static supportsDevhubUsername = false
    protected static requiresProject = true
    protected static varargs = true
    private conn: Connection
    private appC: Org
    private sharedConn: Connection
    private sharedOrg: Org

    public static examples = [
        `$ sfdx ul:feature:merge -m "Some Changes" -n feature1 -v app-central

        Commit the changes and merge it with the parent project branch. 
        This will also update the status on App Central. 
        Note that this status is used when generating the release (merged features will be linked automatically)\n`,
        `$ sfdx ul:feature:merge -m "Some Changes" -n <PR-NO> -v app-central -e EU-CQA`
    ]

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: true,
            description: 'Name of the feature'
        }),

        message: flags.string({
            char: 'm',
            required: true,
            description: 'Message for this merge'
        }),

        org: flags.string({
            char: 'v',
            required: true,
            description: 'The org which hosts App Central'
        }),

        sharedorg: flags.string({
            char: 'e',
            description: `Org you're pulling the PR off`,
            required: false
        }),

        verbose: flags.builtin()
    }

    public async run() {

        this.appC = await Org.create({ aliasOrUsername: this.flags.org })
        this.conn = this.appC.getConnection()
        if (!this.flags.sharedorg) {
            await this.validate()
        }

        let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
        let json: any = await readFile(jsonPath, 'utf-8')
        json = JSON.parse(json)
        let branch: any = json.plugins.branch
        await runSonar.run(['-b', branch, '-c','-v',this.conn.getUsername()])
        await this.merge()
        await this.updateFeature()
    }

    private async updateFeature() {
        try {
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix
            let branch: any = json.plugins.branch
            let res: any = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any = res.records[0].Id
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='SAJ_Feature'`)
            let featureId = res.records[0].Id
            let recordName = ''
            if (this.flags.sharedorg) {
                recordName = `${prefix}-PR-${this.flags.name}`
            } else {
                recordName = `${prefix}-DEV-${this.flags.name}`
            }
            res = await this.conn.query(`select Id FROM SAJ_Release__c where Name='${recordName}' and RecordTypeId='${featureId}' and SAJ_Application__c='${parId}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`There Exists no Feature record with Name ${recordName}`)
            }
            let relId = res.records[0].Id
            this.ux.log(`Updating Feature ${recordName} with id ${relId} with Status as 'Merged'`)
            await DataRecordUpdateCommand.run(['-s', 'SAJ_Release__C', '-i', relId, '-v', `SAJ_Status__c=Merged`, '-u', this.conn.getUsername()])

            this.ux.log(`It's Component Tracking time!`)
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType='SAJ_Release_Component__c' and DeveloperName='SAJ_Components'`)
            let compId: any = res.records[0].Id
            await Diff.run(['-t', `origin/CQA`, '-b', branch, '-z', `${relId},${compId},${this.conn.getUsername()}`])

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async merge() {
        try {
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix
            let branch: any = json.plugins.branch

            SourceRetrieveCommand.id = ''
            if (this.flags.sharedorg && prefix == 'SYS-EU') {
                this.sharedOrg = await Org.create({ aliasOrUsername: this.flags.sharedorg })
                this.sharedConn = this.sharedOrg.getConnection()
                this.ux.startSpinner(`Retrieving Settings for ${this.sharedConn.getUsername()}`)
                await SourceRetrieveCommand.run(['-m', 'Settings', '-u', this.sharedConn.getUsername()])
                this.ux.stopSpinner(`Retrieved Settings!`)
            }

            const git = simplegit()
            await git.add('.')
            let res: any = await git.commit(this.flags['message'])
            this.ux.log(res)

            this.ux.log(`Un-Omitting sfdx-project.json from Git Tracking (If Feature Branch)`)
            await simplegit().raw(
                [
                    'update-index',
                    '--no-skip-worktree',
                    'sfdx-project.json'
                ]
            )
            // RC Update goes here - first, just Apex Classes
            res = await simplegit().diff(['--name-only', '--cached'])
            res = res.split('\n')
            this.ux.log(res.pop(res.length))

            this.ux.log(`Stashing the sfdx-project.json file so it is not Involved in the merge`)
            res = await simplegit().raw(['stash'])
            this.ux.log(res)

            this.ux.log(`Switching to Project Branch ${prefix}`)
            res = await simplegit().raw(['checkout', prefix])
            this.ux.log(res)

            this.ux.log(`Performing a --no-ff merge on ${prefix} from ${branch}`)
            res = await git.merge(['--no-ff', branch])
            this.ux.log(res)

            this.ux.log(`Pushing changes to origin/${prefix}`)
            res = await git.push('origin', prefix)
            this.ux.log(res)

            this.ux.log(`Switching back to Feature branch ${branch}`)
            res = await simplegit().raw(['checkout', branch])
            this.ux.log(res)

            this.ux.log(`Popping the stash to get sfdx-project.json back in ${branch}`)
            res = await simplegit().raw(['stash', 'pop'])
            this.ux.log(res)

            this.ux.log(`Omitting sfdx-project.json from Git Tracking, again (If Feature Branch)`)
            await simplegit().raw(
                [
                    'update-index',
                    '--skip-worktree',
                    'sfdx-project.json'
                ]
            )

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

    private async validate() {
        try {
            let username: any = this.conn.getUsername()
            let jsonPath = `${join(process.cwd(), 'sfdx-project.json')}`
            let json: any = await readFile(jsonPath, 'utf-8')
            json = JSON.parse(json)
            let prefix: any = json.plugins.prefix

            let res: any = await this.conn.query(`select id from User where Username='${username}'`)
            let userId: any = res.records[0].Id
            res = await this.conn.query(`select Id,Name from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId: any
            if (res.records.length == 0) {
                throw new SfdxError(`Details for Prefix ${prefix} does not exit on SAJ_Project_Dev_Prefix__c`)
            } else {
                parId = res.records[0].Id
            }
            res = await this.conn.query(`select UserOrGroupId from SAJ_App__Share where ParentId='${parId}' and UserOrGroupId='${userId}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`${username} is not authorized to work on ProjectPrefix ${prefix}`)
            } else {
                this.ux.log(`${username} is authorized to work on ProjectPrefix ${prefix}`)
                this.ux.log(`Validation Step Passed!`)
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}