import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command';
import { SfdxError, Connection } from '@salesforce/core';
import { AnyJson } from '@salesforce/ts-types';
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run';
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update';

export default class Run extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;

    protected static flagsConfig: FlagsConfig = {

        prefix: flags.string({
            char: 'r',
            required: false,
            description: 'Prefix of the Release'
        }),

        name: flags.string({
            char: 'n',
            required: false,
            description: 'Name of the feature'
        }),

        org: flags.string({
            char: 'v',
            required: false,
            description: 'Org Hosting App Central'
        }),

        payload: flags.string({
            char: 'p',
            required: true,
            description: 'Json Update Payload for the feature'
        }),
    
        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.conn = this.org.getConnection()
        await this.featureRecord()

        return process.exit(0)
    }

    private async featureRecord() {
        try {
            let prefix : any = this.flags['prefix']
            let res: any = await this.conn.query(`select Id from SAJ_App__c where SAJ_Project_Dev_Prefix__c='${prefix}'`)
            let parId : any = res.records[0].Id
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='SAJ_Feature'`) 
            let featureId = res.records[0].Id
            let recordName : any = `${prefix}-DEV-${this.flags['name']}`
            res = await this.conn.query(`select Name, Id FROM SAJ_Release__c where Name='${recordName}' and RecordTypeId='${featureId}' and SAJ_Application__c='${parId}'`)
            if(res.records.length==0){
                throw new SfdxError(`${recordName} does not exist for prefix ${prefix}!`)
            }
            let valString : any = ''
            let jsonPayload : any = JSON.parse(this.flags['payload'])
            for(const key in jsonPayload){
                if(valString.length==0){
                    valString=`${key}=${jsonPayload[key]}`
                }else{
                    valString=`${valString} ${key}=${jsonPayload[key]}`
                }
            }

            this.ux.log(`Value to update is: ${valString}`)
            this.ux.log(`Updating Feature ${recordName} with id ${res.records[0].Id} with JSON Payload`)
            await DataRecordUpdateCommand.run(['-s','SAJ_Release__C','-i',res.records[0].Id,'-v',valString])
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}