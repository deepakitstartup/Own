import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { config } from "dotenv"
import { resolve } from "path"
config({ path: resolve(__dirname, "../../../../.env") })

export default class Clone extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private prod: Connection;
    private prodOrg: Org;

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: false,
            description: 'Name of Sandbox to Create'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.prodOrg = await Org.create({ aliasOrUsername: process.env.PROD_SB_UNAME })
        this.prod = this.prodOrg.getConnection()
        this.conn = this.org.getConnection()
        await this.work()

        return process.exit(0)
    }

    private async work() {
        try {
            let CqaName = `CICDDEV3`
            this.ux.log(`Getting SandboxInfoId for ${CqaName} - PILOT QA Sandbox`)
            let res : any = await this.prod.tooling.sobject('SandboxProcess').findOne(`SandboxName='${CqaName}'`)

            this.ux.log(`SandboxInfoId for ${CqaName} is ${res.SandboxInfoId}`)
            this.ux.log(`Cloning ${this.flags.name} from ${CqaName}!`)
            
            let sandboxdef = [{
                AutoActivate: true,
                Description: 'Cloned Validation Box for ALM Pilot',
                SandboxName: this.flags.name,
                SourceId: res.SandboxInfoId
            }]

            res = await this.prod.tooling.sobject('SandboxInfo').create(sandboxdef)

            this.ux.log(`Updating Status on ALM_Environment__c`)
            res = await this.conn.query(`Select Id from ALM_Environment__c where Name='${this.flags.name}'`)
            DataRecordUpdateCommand.id = 'force:apex:data:update'
            await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-i', res.records[0].Id, '-v', `ALM_Status__c=Cloning`])
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}