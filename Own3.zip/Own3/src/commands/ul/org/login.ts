import { AnyJson, getString } from "@salesforce/ts-types"
import { flags, SfdxCommand } from "@salesforce/command"
import { Connection } from "jsforce"
import { SfdxError, AuthInfo, Aliases, ConfigGroup } from "@salesforce/core"

export default class Login extends SfdxCommand {

  public static examples = [
    `$ sfdx ul:org:login -u jenkins.deploy@unilever.com.cicddev3 -p Xasdapassx2w2  -a jenks-ci3
      Authorized to jenkins.deploy@unilever.com.cicddev3
  `]

  protected static flagsConfig = {
    username: flags.string({
      required: true,
      char: "u",
      description: 'Username for the org'
    }),

    password: flags.string({
      required: true,
      char: "p",
      description: 'Password for the username'
    }),

    securitytoken: flags.string({
      required: false,
      char: "s",
      description: 'Security token (if required)'
    }),

    url: flags.url({
      required: false,
      char: "r",
      description: 'Url to pass for the instance'
    }),

    alias: flags.string({
      required: false,
      char: "a",
      description: 'alias to save this as'
    })
  }

  loginUrl: string
  password: string

  public async run(): Promise<AnyJson> {

    if (this.flags.url) this.loginUrl = this.flags.url
    else this.loginUrl = "https://test.salesforce.com"

    if (this.flags.securitytoken)
      this.password = this.flags.password.concat(this.flags.securitytoken)
    else this.password = this.flags.password

    let conn = new Connection({
      loginUrl: this.loginUrl
    })

    await conn.login(this.flags.username, this.password, function(
      err,
      userInfo
    ) {
      if (err) {
        throw new SfdxError("Unable to connect to the target org")
      }
    })

    const accessTokenOptions = {
      accessToken: conn.accessToken,
      instanceUrl: conn.instanceUrl,
      loginUrl: this.loginUrl,
      orgId: getString(conn, "userInfo.organizationId")
    }

    const auth = await AuthInfo.create({
      username: this.flags.username,
      accessTokenOptions
    })
    await auth.save()

    if (this.flags.alias) {
      const aliases = await Aliases.create(
        ConfigGroup.getOptions("orgs", "alias.json")
      )
      aliases.set(this.flags.alias, this.flags.username)
      await aliases.write()
    }

    this.ux.log(`Authorized to ${this.flags.username}`)

    return { username: this.flags.username, accessTokenOptions }
  }
}