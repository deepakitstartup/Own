import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import Delete  from './delete'
import Clone from './clone'
import Status from './status'
import Create from './create'
import Deploy from './deploy'

export default class Run extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;

    protected static flagsConfig: FlagsConfig = {

        org: flags.string({
            char: 'v',
            required: false,
            description: 'Org Hosting App Central'
        }),
    
        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.conn = this.org.getConnection()
        await this.work()

        return process.exit(0)
    }
    
    private async work() {
        try {
            let res : any = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Environment__C' and DeveloperName='SAJ_ScratchOrg'`)
            let scratchId = res.records[0].Id
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Environment__C' and DeveloperName='SAJ_Snapshot'`)
            let snapshotId = res.records[0].Id
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Environment__C' and DeveloperName='SAJ_Sandbox'`)
            let sandboxId = res.records[0].Id

            // Delete
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='Delete' and SAJ_Type__c='Validation' and RecordTypeId='${sandboxId}'`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:delete for SandboxName ${record.Name}`)
                    await Delete.run(['-n',record.Name,'-e','Sandbox'])
                }
            }
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='Delete' and SAJ_Type__c='Validation' and RecordTypeId='${scratchId}'`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:delete for Scratchorg ${record.Name}`)
                    await Delete.run(['-n',record.Name,'-e','Scratchorg'])
                }
            }
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='Delete' and SAJ_Type__c='Validation' and RecordTypeId='${snapshotId}'`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:delete for SandboxName ${record.Name}`)
                    await Delete.run(['-n',record.Name,'-e','Snapshot'])
                }
            }

            // Create
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='New' and SAJ_Type__c='Validation' and RecordTypeId='${sandboxId}'`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:delete for SandboxName ${record.Name}`)
                    await Create.run(['-n',record.Name,'-e','Sandbox'])
                }
            }
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='New' and SAJ_Type__c='Validation' and RecordTypeId='${scratchId}'`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:delete for SandboxName ${record.Name}`)
                    await Create.run(['-n',record.Name,'-e','Scratchorg'])
                }
            }
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='New' and SAJ_Type__c='Validation' and RecordTypeId='${snapshotId}'`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:delete for SandboxName ${record.Name}`)
                    await Create.run(['-n',record.Name,'-e','Snapshot'])
                }
            }

            res = await this.conn.query(`select Name FROM SAJ_Environment__c where ( SAJ_Status__c='New' or SAJ_Status__c='Rebuild Clone' ) and SAJ_Type__c='Validation' and RecordTypeId='${sandboxId}`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:clone for SandboxName ${record.Name}`)
                    await Clone.run(['-n',record.Name])
                }
            }
            
            res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Release__C' and DeveloperName='Release'`)
            let releaseId = res.records[0].RecordType.Id
            res = await this.conn.query(`select Name, SAJ_Jenkins_Build__c from SAJ_Release__c where RecordTypeId='${releaseId}' and SAJ_Type__c='Release' and SAJ_Status__c='New'`)
            if(res.records.length>0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:deploy for Release Record ${record.Name} with PR Url ${record.SAJ_Jenkins_Build__c}`)
                    await Deploy.run(['-l',record.SAJ_Jenkins_Build__c])
                }
            }
            
            // Status
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='Creating' or SAJ_Status__c='Cloning' and SAJ_Type__c='Validation' and RecordTypeId='${sandboxId}`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:status for SandboxName ${record.Name}`)
                    await Status.run(['-n',record.Name,'-e','Sandbox'])
                }
            }
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='Creating' and SAJ_Type__c='Validation' and RecordTypeId='${scratchId}`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:status for Scratchorg ${record.Name}`)
                    await Status.run(['-n',record.Name,'-e','Scratchorg'])
                }
            }
            res = await this.conn.query(`select Name FROM SAJ_Environment__c where SAJ_Status__c='Creating' and SAJ_Type__c='Validation' and RecordTypeId='${snapshotId}`)
            if(res.records.length > 0){
                for(const record of res.records){
                    this.ux.log(`Calling ul:org:status for Snapshot ${record.Name}`)
                    await Status.run(['-n',record.Name,'-e','Snapshot'])
                }
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}