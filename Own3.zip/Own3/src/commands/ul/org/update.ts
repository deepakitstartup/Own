import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command';
import { SfdxError, Connection } from '@salesforce/core';
import { AnyJson } from '@salesforce/ts-types';
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run';
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update';

export default class Run extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: true,
            description: 'Name of The Environment'
        }),

        org: flags.string({
            char: 'v',
            required: false,
            description: 'Org Hosting App Central'
        }),

        payload: flags.string({
            char: 'p',
            required: false,
            description: 'Json Update Payload for the Release'
        }),

        release: flags.string({
            char: 'r',
            required: false,
            description: "Name of Release Last Built (To update on ScratchOrg)"
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.conn = this.org.getConnection()
        await this.envRecord()

        return process.exit(0)
    }

    private async envRecord() {
        try {
            let envName: any = this.flags['name']
            let res: any = await this.conn.query(`select Id FROM SAJ_Environment__c where Name='${envName}'`)
            if (res.records.length == 0) {
                throw new SfdxError(`Environment ${envName} does not exist!`)
            }
            let valString: any = ''
            if (this.flags.payload) {
                this.ux.log(this.flags['payload'])
                let jsonPayload: any = JSON.parse(this.flags['payload'])
                for (const key in jsonPayload) {
                    if (valString.length == 0) {
                        valString = `${key}=${jsonPayload[key]}`
                    } else {
                        valString = `${valString} ${key}=${jsonPayload[key]}`
                    }
                }

                this.ux.log(`Value to update is: ${valString}`)
                this.ux.log(`Updating Enviroment ${envName} with id ${res.records[0].Id} with JSON Payload`)
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Environment__c', '-i', res.records[0].Id, '-v', valString])
            }

            // if (this.flags.release) {
            //     this.ux.log(`Updating Enviroment ${envName} with id ${res.records[0].Id} with the last release`)
            //     await DataRecordUpdateCommand.run(['-s', 'SAJ_Environment__c', '-i', res.records[0].Id, '-v', `SAJ_Last_Release__c=${this.flags.release}`])
            // }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}