import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import Axios from 'axios'
import { config } from "dotenv"
import { resolve } from "path"

config({ path: resolve(__dirname, "../../../../.env") })

export default class Deploy extends SfdxCommand {

    public static examples = ApexTestRunCommand.help
    protected static requiresUsername = true
    protected static supportsDevhubUsername = false
    protected static requiresProject = true
    protected static varargs = true

    protected static flagsConfig: FlagsConfig = {

        url: flags.string({
            char: 'l',
            required: true,
            description: 'PR URL For this release'
        }),

        org: flags.string({
            char: 'v',
            required: false,
            description: 'The org which hosts App Central'
        }),
    
        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        await this.jenkinsJob(this.flags.url)

        return process.exit(0)
    }

    private async jenkinsJob(prUrl){
        try {
            let id : any = prUrl.split('/')
            await Axios({
                url: `${process.env.JENKINS_URL}/job/sfdx-eu-fixed/job/PR-${id[8]}/build`,
                method: 'POST',
                auth: {
                    username: process.env.JENKINS_TOKEN,
                    password: ''
                }
            })
            this.ux.log(`Jenkins PR Job with id ${id[8]} Triggered Successfully!`)
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}