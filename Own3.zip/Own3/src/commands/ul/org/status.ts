import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { UserPasswordGenerateCommand } from 'salesforce-alm/dist/commands/force/user/password/generate'
import { OrgSnapshotListCommand } from 'salesforce-alm/dist/commands/force/org/snapshot/list'

export default class Status extends SfdxCommand {

    public static examples = ApexTestRunCommand.help
    protected static requiresUsername = true
    protected static supportsDevhubUsername = false
    protected static requiresProject = true
    protected static varargs = true
    private conn: Connection
    private prod: Connection
    private prodOrg: Org

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: true,
            description: 'Name of Org to check status for'
        }),

        envtype: flags.string({
            char: 'e',
            required: false,
            description: 'Type of Environment'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.prodOrg = await Org.create({ aliasOrUsername: process.env.PROD_SB_UNAME })
        this.prod = this.prodOrg.getConnection()
        this.conn = this.org.getConnection()
        await this.work()

        return process.exit(0)
    }

    private async work() {
        try {
            if (this.flags.envtype == 'Scratchorg') {
                let res: any = await this.prod.query(`select Id FROM ActiveScratchOrg where OrgName='${this.flags.name}'`)
                if (res.records.length > 0) {
                    let res: any = await this.prod.query(`select UserName from ScratchOrgInfo where OrgName='${this.flags.name}'`)
                    UserPasswordGenerateCommand.id = 'force:user:password:generate'
                    res = await UserPasswordGenerateCommand.run(['-u', res.records[0].UserName, '--json'])
                    await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-w', `Name=${this.flags.name}`, '-v', `ALM_Password__c=${res.result.password} ALM_Status__c=Ready`])
                    this.ux.log(`Password Created and Updated for scratchOrg ${this.flags.name}!`)
                }
            } else if (this.flags.envtype == 'Snapshot') {
                let res: any = await OrgSnapshotListCommand.run(['-v', this.prod.getUsername(), '--json'])
                for (const record of res.result) {
                    if (record.SnapshotName == this.flags.name && record.Status == 'Active') {
                        await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-w', `Name=${this.flags.name}`, '-v', 'ALM_Status__c=Ready'])
                        this.ux.log(`Snapshot ${this.flags.name} is now Active!`)
                        continue
                    }
                }
            } else if (this.flags.envtype == 'Sandbox') {
                this.ux.log(`Getting Status for SandboxName ${this.flags.name}`)
                let res: any = await this.prod.tooling.sobject('SandboxProcess').findOne(`SandboxName='${this.flags.name}'`)
                this.ux.log(`Sandbox ${res.SandboxName} with SandboxInfoId ${res.SandboxInfoId} has status ${res.Status}`)

                this.ux.log(`Updating Status on SAJ_Environment__c`)
                let res1: any = await this.conn.query(`Select Id from SAJ_Environment__c where Name=${this.flags.name}`)

                DataRecordUpdateCommand.id = ''
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Environment__c', '-i', res1.records[0].Id, '-v', `ALM_Status__c=${res.Status}`])
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}