import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { DataRecordDeleteCommand } from 'salesforce-alm/dist/commands/force/data/record/delete'
import { OrgSnapshotDeleteCommand } from 'salesforce-alm/dist/commands/force/org/snapshot/delete'
import { config } from "dotenv"
import { resolve } from "path"
config({ path: resolve(__dirname, "../../../../.env") })

export default class Delete extends SfdxCommand {

    public static examples = ApexTestRunCommand.help
    protected static requiresUsername = true
    protected static supportsDevhubUsername = false
    protected static requiresProject = true
    protected static varargs = true
    private conn: Connection
    private prod: Connection
    private prodOrg: Org

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: false,
            description: 'Name of Org to Delete'
        }),

        envtype: flags.string({
            char: 'e',
            required: false,
            description: 'Type of Environment'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.prodOrg = await Org.create({ aliasOrUsername: process.env.PROD_SB_UNAME })
        this.prod = this.prodOrg.getConnection()
        this.conn = this.org.getConnection()
        await this.work()

        return process.exit(0)
    }

    private async work() {
        try {
            if (this.flags.envtype == 'Scratchorg') {
                DataRecordDeleteCommand.id = 'force:data:record:delete'
                await DataRecordDeleteCommand.run(['-s','ActiveScratchOrg','-w',`OrgName='${this.flags.name}'`,'-u',this.prod.getUsername()])
                await DataRecordDeleteCommand.run(['-s','ScratchOrgInfo','-w',`OrgName='${this.flags.name}'`,'-u',this.prod.getUsername()])
                await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-w',`Name='${this.flags.name}'`, '-v', `SAJ_Status__c=Deleted`])
                this.ux.log(`ScratchOrg ${this.flags.name} has been deleted`)
            } else if (this.flags.envtype == 'Snapshot') {
                OrgSnapshotDeleteCommand.id = 'sfdx force:org:snapshot:delete'
                OrgSnapshotDeleteCommand.run(['-s',this.flags.name,'-v',this.prod.getUsername()])
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Environment__c', '-w',`Name='${this.flags.name}'`, '-v', `SAJ_Status__c=Deleted`])
                this.ux.log(`Org Snapshot ${this.flags.name} has been deleted!`)
            } else if (this.flags.envtype == 'Sandbox') {
                let res: any = await this.prod.tooling.sobject('SandboxInfo').findOne(`SandboxName='${this.flags.name}'`)
                this.ux.log(`Sandbox ${res.SandboxName} with id ${res.Id} has IsDeleted ${res.IsDeleted}`)
                
                res = await this.prod.tooling.sobject('SandboxInfo').delete(res.Id)

                this.ux.log(`Updating Status on SAJ_Environment__c`)
                let res1: any = await this.conn.query(`Select Id from SAJ_Environment__c where Name='${this.flags.name}'`)
                await DataRecordUpdateCommand.run(['-s', 'SAJ_Environment__c', '-i', res1.records[0].Id, '-v', `SAJ_Status__c=Expired`])
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}