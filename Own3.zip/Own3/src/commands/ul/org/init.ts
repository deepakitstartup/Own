import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command';
import { SfdxError, Connection } from '@salesforce/core';
import { AnyJson } from '@salesforce/ts-types';
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run';
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update';
import { DataRecordCreateCommand } from 'salesforce-alm/dist/commands/force/data/record/create';

export default class Run extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;

    protected static flagsConfig: FlagsConfig = {

        org: flags.string({
            char: 'v',
            required: false,
            description: 'Org Hosting App Central'
        }),

        value: flags.number({
            char: 'x',
            description: 'Number of Validation Sandboxes to Create'
        }),
    
        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.conn = this.org.getConnection()
        await this.work()

        return process.exit(0)
    }

    private async work() {
        try {
            DataRecordUpdateCommand.id = ''
            DataRecordCreateCommand.id = ''

            let res : any = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'SAJ_Environment__C' and DeveloperName='Scratchorg'`)
            let scratchId = res.records[0].Id

            res = await this.conn.query(`select Id FROM SAJ_Environment__c where ( SAJ_Status__c='Building' or SAJ_Status__c='Cloning' ) and SAJ_Type__c='Validation and RecordTypeId='${scratchId}'`)
            if(res.records.length>0){
                this.ux.log('There are Sandboxes which are either Building or Cloning!')
                process.exit(0)
            }
            
            res = await this.conn.query(`select Id FROM SAJ_Environment__c where SAJ_Status__c='Expired' and SAJ_Type__c='Validation' and RecordTypeId='${scratchId}`)
            if(res.records.length>0){
                for(const record of res.records){
                    this.ux.log(`Sandbox ${record.Name} with id ${record.Id} has Expired Status!`)
                }
            }

            let namesUniq : any = [1,2,3]
            let count = 0
            res = await this.conn.query(`select Id, Name FROM SAJ_Environment__c where SAJ_Status__c='Rebuild' and SAJ_Type__c='Validation' and RecordTypeId='${scratchId}`)
            if(res.records.length==0){
                this.ux.log(`All Current Validation Scratchorg are marked for deletion!`)
            }else{
                for(const record of res.records){
                    this.ux.log(`Updating Validation Scratchorg ${record.Name} with id ${record.Id} to have the 'Delete' Flag`)
                    await DataRecordUpdateCommand.run(['-s','SAJ_Environment__c','-i',record.Id,'-v',`SAJ_Status__c=Delete`])
                    let num = record.Name.split('val')[1]
                    namesUniq.push(num)
                    count++
                }
            }

            if(count>0){
                this.ux.log(`Creating Records for ${count} New Validation Scratchorgs on SAJ_Environment__c`)
                for(let i=0;i<=count;i++){
                    this.ux.log(`Creating a Record for Validation Scratchorg val${count+7} with 'New' Status`)
                    await DataRecordCreateCommand.run(['-s','SAJ_Environment__C','-v',`Name=val${count+7} SAJ_Status__c=New SAJ_Type__c=Validation RecordTypeId='${scratchId}`])
                }
            }

        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}