import { flags, SfdxCommand } from '@salesforce/command'
import { Messages, SfdxError, AuthInfo, Aliases, fs} from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import * as jsforce from 'jsforce'
import { SaveResult, UserInfo } from 'jsforce'

// Initialize Messages with the current plugin directory
Messages.importMessagesDirectory(__dirname)

// Load the specific messages for this file. Messages from @salesforce/command, @salesforce/core,
// or any library that is using the messages framework can also be loaded this way.
const messages = Messages.loadMessages('ul', 'auth')

export default class Auth extends SfdxCommand {
  public static description = messages.getMessage('commandDescription')

  public static examples = [
  `$ sfdx hello:auth -f <path to key file> -u <username> -r https://login.salesforce.com
  Created Connected app and authenticated user: XXX`
  ]

  public static args = [{name: 'file'}]

  protected static flagsConfig = {
    // flag with a value (-n, --name=VALUE)
    certfile: flags.string({char: 'c', description: messages.getMessage('certfileFlagDescription')}),
    keyfile: flags.string({char: 'k', description: messages.getMessage('keyfileFlagDescription')}),
    username: flags.string({char: 'u', description: messages.getMessage('usernameFlagDescription')}),
    password: flags.string({char: 'p', description: messages.getMessage('passwordFlagDescription')}),
    instanceurl: flags.string({char: 'r', description: messages.getMessage('instanceurlDescription')}),
    alias: flags.string({char: 'a', description: messages.getMessage('aliasDescription')})
  }

  // Comment this out if your command does not require an org username
  protected static requiresUsername = false

  // Comment this out if your command does not support a hub org username
  protected static supportsDevhubUsername = false

  // Set this to true if your command requires a project workspace 'requiresProject' is false by default
  protected static requiresProject = false

  public async run(): Promise<AnyJson> {
    const version = '47.0'
    const approvedProfile = 'System Administrator'
    const connectedAppName = 'ULSFDX'
    const consumerKeyPrefix = 'UL'

    const certFile = this.flags.certfile || 'certificate.pem'
    const keyFile = this.flags.keyfile || 'key.pem'
    const instanceUrl = this.flags.instanceurl || 'https://test.salesforce.com'
    const username = this.flags.username as string
    const password = this.flags.password as string
    
    const cert = await fs.readFile(certFile,'utf8')
    
    let outputString = 'Message '
    outputString = `${outputString} : XXX`

    if (username == null || username.length < 1) {
      throw new SfdxError(messages.getMessage('errorNoUsername', ['Error']))
    }

    if (password == null || password.length < 1) {
      throw new SfdxError(messages.getMessage('errorNoPassword', ['Error']))
    }

    // ### Try to login
    this.ux.log('Attempting login')
    const conn:any = new jsforce.Connection({
      // you can change loginUrl to connect to sandbox or prerelease env.
      version : version,
      loginUrl: instanceUrl
    })
  
    const userinfo :any = await conn.login(username, password) as UserInfo
    this.ux.log(userinfo)
    if (userinfo == null) {
      throw new SfdxError(messages.getMessage('errorConnection', ['Error']))
    }
    this.ux.log (`connected to org: ${userinfo.organizationId}`)

    // ### Try to find the Connected App
    let connectedAppFound = false

    const listmetadata = [{
      type: 'ConnectedApp'
    }]

    const lres :any = await conn.metadata.list(listmetadata,version)
  
    for ( const f of lres) {
      if (f.fullName.localeCompare(connectedAppName) === 0) {
        connectedAppFound = true
        this.ux.log(`ConnectedApp already installed: ${connectedAppName}`)
      }
    }

    // ### construct the connected App 
    const consumerKeyFiller = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
    const fixlen = 32
    let consumerKey = `${consumerKeyPrefix}${userinfo.organizationId}`
    const mod = consumerKey.length % fixlen
    if (mod > 0) {
      consumerKey = consumerKey.concat(consumerKeyFiller.substring(0,fixlen - mod))
    }

    const connectedapp = [{
        contactEmail: 'ctt@unilever.com',
        description: 'Used to authenticate sfdx',
        fullName: connectedAppName,
        label: connectedAppName,
        profileName : [approvedProfile],
        oauthConfig: {
            callbackUrl: 'https://login.salesforce.com/services/oauth2/callback',
            consumerKey: consumerKey,
            certificate: cert,
            isAdminApproved : true,
            scopes: [
                'Basic',
                'Api',
                'RefreshToken'
            ]
        }
      }]

    this.ux.log(`Consumer key: ${consumerKey}`)

      // ### Create it when it was not found
    const mdtype = 'ConnectedApp'
    if (!connectedAppFound) {

      let mdresult = await conn.metadata.create(mdtype, connectedapp) as SaveResult
      if (mdresult.success) {

        this.ux.log(`App Created: ${connectedAppName}`)

        await conn.metadata.update(mdtype, connectedapp)
        this.ux.log(`App Updated: ${connectedAppName}`)

      } else {
        throw new SfdxError(messages.getMessage('errorCreateConnectedApp', ['Error']))
      }
     }

     // ### Authenticate the user and store in config
    const oauth2Options = {
         privateKeyFile : keyFile,
         clientId: consumerKey,
         loginUrl: instanceUrl,
         redirectUri: 'https://login.salesforce.com/services/oauth2/callback'
     }
 
    const authInfo = await AuthInfo.create({username,  oauth2Options})
    if (authInfo != null) {
      await authInfo.save()
      this.ux.log(`Authenticated user: ${authInfo.getUsername()}`)

      // ### create the alias
      const orgalias = this.flags.alias as string
      if (orgalias != null) {
      const aliases = await Aliases.create({defaultGroup : 'orgs'})
      aliases.set(orgalias, username)
      await aliases.write()
    }
      

    } else {

      throw new SfdxError(messages.getMessage('errorAuthUser', ['Error']))

    }

    this.ux.log('Done')

    return { name: this.flags.name, outputString}

  }
    // Return an object to be displayed with --json


}
