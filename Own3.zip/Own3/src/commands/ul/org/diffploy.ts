import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { SourceDeployCommand } from 'salesforce-alm/dist/commands/force/source/deploy'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { DataRecordCreateCommand } from 'salesforce-alm/dist/commands/force/data/record/create'
import { join } from 'path'
import { promisify } from 'util'
import { readFile, writeFile, exists } from 'fs'
import * as simplegit from 'simple-git/promise'
import * as xml2js from 'xml2js'
import * as _ from 'lodash'
const parser = new xml2js.Parser
const readFileA = promisify(readFile)
const writeFileA = promisify(writeFile)
const existsA = promisify(exists)

export default class Diff extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private appConn: Connection
    private appC: Org

    protected static flagsConfig: FlagsConfig = {

        org: flags.string({
            char: 'v',
            description: 'Org App Central is held on',
            required: false
        }),

        tbranch: flags.string({
            char: 't',
            description: 'Target Branch to compare to',
            required: true
        }),

        cbranch: flags.string({
            char: 'b',
            description: 'Current branch',
            required: true
        }),

        settings: flags.boolean({
            char: 's',
            description: 'Try To deploy settings to org first (If found)'
        }),

        trackcomponents: flags.string({
            char: 'z',
            description: 'Track Components during a feature:merge or release:create',
            required: false
        }),

        buildurl: flags.string({
            char: 'p',
            description: 'Jenkins Build URL',
            required: false
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.conn = this.org.getConnection()
        if (this.flags.org) {
            this.appC = await Org.create({ aliasOrUsername: this.flags.org })
            this.appConn = this.appC.getConnection()
        }
        await this.work()
        return process.exit(0)
    }

    private async work() {
        try {
            let jsonPath = `${join(process.cwd(), 'envDets.json')}`
            SourceDeployCommand.id = 'force:source:deploy'
            const git = simplegit()
            if (this.flags.settings) {
                let res: any = await git.diff([`${this.flags.tbranch}..${this.flags.cbranch}`, '--name-only', '--diff-filter=AM', 'force-app/main/default/settings/'])
                res = res.replace(/[\n]/g, ',').substr(0, res.length - 1)
                if (res.length == 0) {
                    this.ux.log(`No modified Settings found!`)
                } else {
                    try {
                        this.ux.log(`Deploying Settings to ${this.conn.getUsername()}\n`)
                        await SourceDeployCommand.run(['-u', this.flags.targetusername, '-p', res])
                    } catch (error) {
                        this.ux.log(`There was an Error in Deploying Settings`)
                        this.ux.log(`Marking this Release as FULL Rebuild Required`)
                        this.ux.log(`Removing Validation environment assigned - the CTT Arch will go through this, and assign you a new val environment`)
                        await DataRecordUpdateCommand.run(['-s', 'SAJ_Release__c', '-w', `Name=${this.flags.cbranch.split('/')[1]}`, '-v', `SAJ_Environment__c=null SAJ_Jenkins_Build_Status__c='FULL Rebuild Required'`])
                        await DataRecordUpdateCommand.run(['-s', 'SAJ_Environment__c', '-w', `SAJ_Username__c=${this.conn.getUsername()}`, '-v', 'SAJ_Status__c=Rebuild'])
                        process.exit(1)
                    }

                    if (await existsA(jsonPath)) {
                        let json: any = await readFileA(jsonPath, 'utf-8')
                        json = JSON.parse(json)
                        json.source = res
                        this.ux.log(`Writing Deployed Settings to JSON`)
                        await writeFileA(jsonPath, JSON.stringify(json, null, 2), 'utf-8')
                    }
                }
            }

            let res: any
            let fileN: any
            if (this.flags.settings) {
                res = await git.diff([`${this.flags.tbranch}..${this.flags.cbranch}`, '--name-only', '--diff-filter=AM', 'force-app/', `:(exclude)force-app/main/default/settings/*`])
            } else {
                res = await git.diff([`${this.flags.tbranch}..${this.flags.cbranch}`, '--name-only', '--diff-filter=AM', 'force-app/'])
            }

            res = res.replace(/[\n]/g, ',').substr(0, res.length - 1)
            if (res.length == 0) {
                this.ux.log(`No files picked up in this git Diff?`)
            } else {
                let filesArr: any = res.split(',')
                let withoutMeta = []
                let withMeta = []
                res = await this.conn.metadata.describe()
                for (const record of res.metadataObjects) {
                    if (record.metaFile && !record.inFolder) {
                        withMeta.push(record)
                    } else if (!record.metaFile && !record.inFolder) {
                        withoutMeta.push(record)
                    }
                }
                for (const file of filesArr) {
                    let wM: any = withMeta.filter(value => value.directoryName == file.split('/')[3])
                    if (wM.length > 0) {
                        let metaPath = `${file}-meta.xml`
                        if (file.includes('-meta.xml')) {
                            continue
                        }
                        if (!filesArr.includes(metaPath)) {
                            this.ux.log(`This Pr does not include Metadata for ${file}!`)
                            this.ux.log(`Adding ${metaPath} to File Array`)
                            filesArr.push(metaPath)
                        }

                        if (this.flags.trackcomponents) {
                            let Ids = this.flags.trackcomponents
                            let relId = Ids.split(',')[0]
                            let compId = Ids.split(',')[1]
                            let appcUname = Ids.split(',')[2]
                            let xmlData = await readFileA(metaPath, 'utf-8')
                            let val = await parser.parseStringPromise(xmlData)
                            if (_.has(val, `${wM[0].xmlName}.apiVersion`)) {
                                let fileName = file.split('/')
                                fileName = fileName[fileName.length - 1]
                                this.ux.log(`Creating Release Component for ${fileName} with apiVersion ${val[wM[0].xmlName].apiVersion[0]}`)
                                await DataRecordCreateCommand.run(['-s', 'SAJ_Release_Component__c', '-v', `Name=${fileName} SAJ_API_Version__c=${val[wM[0].xmlName].apiVersion[0]} SAJ_Component_Details__c=${file} SAJ_Component_Type__c=${wM[0].xmlName} SAJ_Status__c=Created RecordTypeId=${compId} SAJ_Release__c=${relId}`, '-u', appcUname])
                            } else {
                                let fileName = file.split('/')
                                fileName = fileName[fileName.length - 1]
                                this.ux.log(`Creating Release Component for ${fileName}`)
                                await DataRecordCreateCommand.run(['-s', 'SAJ_Release_Component__c', '-v', `Name=${fileName} SAJ_Component_Details__c=${file} SAJ_Component_Type__c=${wM[0].xmlName} SAJ_Status__c=Created RecordTypeId=${compId} SAJ_Release__c=${relId}`, '-u', appcUname])
                            }
                        }

                    }

                    let wOM = withoutMeta.filter(value => value.directoryName == file.split('/')[3])
                    if (wOM.length > 0) {
                        if (this.flags.trackcomponents) {
                            let Ids = this.flags.trackcomponents
                            let relId = Ids.split(',')[0]
                            let compId = Ids.split(',')[1]
                            let appcUname = Ids.split(',')[2]
                            let fileName = file.split('/')
                            fileName = fileName[fileName.length - 1]
                            this.ux.log(`Creating Release Component for ${fileName}`)
                            await DataRecordCreateCommand.run(['-s', 'SAJ_Release_Component__c', '-v', `Name=${fileName} SAJ_Component_Details__c=${file} SAJ_Component_Type__c=${wOM[0].xmlName} SAJ_Status__c=Created RecordTypeId=${compId} SAJ_Release__c=${relId}`, '-u', appcUname])
                        }
                    }

                }
                if (this.flags.trackcomponents) {
                    return process.exit(0)
                }
                
                this.ux.log(filesArr)
                fileN = filesArr.join(',')
                // this.ux.log(fileN)
                this.ux.log(`\nDeploying Source to ${this.conn.getUsername()}\n`)
                await SourceDeployCommand.run(['-u', this.flags.targetusername, '-p', fileN])

            }

            if (this.flags.buildurl) {
                this.ux.log(`\nSince all components have been deployed for ${this.flags.cbranch.split('/')[1]}`)
                this.ux.log(`We're Tracking deployed components on SAJ_Release_Component_Environment__c`)
                let res: any = await this.appConn.query(`select Id from SAJ_Release__c where Name='${this.flags.cbranch.split('/')[1]}'`)
                let relId: any = res.records[0].Id
                res = await this.appConn.query(`select Name, Id from SAJ_Release_Environment__c where SAJ_Release__c='${res.records[0].Id}' and SAJ_Jenkins_Build__c='${this.flags.buildurl}'`)
                let buildId = res.records[0].Id
                res = await this.appConn.query(`select Name, Id from SAJ_Release_Component__c where SAJ_Release__c='${relId}'`)
                for (const record of res.records) {
                    await DataRecordCreateCommand.run(['-s', 'SAJ_Release_Component_Environment__c', '-v', `Name=${record.Name} SAJ_Release_Component__c=${record.Id} SAJ_Deployment_Status__c=Deployed SAJ_Release_Environment__c=${buildId}`, '-u', this.appConn.getUsername()])
                }
            }

            if (await existsA(jsonPath)) {
                let json: any = await readFileA(jsonPath, 'utf-8')
                json = JSON.parse(json)
                if (_.has(json,'source')) {
                    json.source = `${json.source},${fileN}`
                } else {
                    json.source = fileN
                }
                this.ux.log(`\nWriting Deployed Source to JSON`)
                await writeFileA(jsonPath, JSON.stringify(json, null, 2), 'utf-8')
            }
            process.exit(0)
        } catch (error) {
            this.ux.log(error.message)
            process.exit(1)
        }
    }

}