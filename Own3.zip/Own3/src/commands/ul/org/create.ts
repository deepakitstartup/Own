import { SfdxCommand, FlagsConfig, flags } from '@salesforce/command'
import { SfdxError, Connection, Org } from '@salesforce/core'
import { AnyJson } from '@salesforce/ts-types'
import { ApexTestRunCommand } from 'salesforce-alm/dist/commands/force/apex/test/run'
import { DataRecordUpdateCommand } from 'salesforce-alm/dist/commands/force/data/record/update'
import { OrgCreateCommand } from 'salesforce-alm/dist/commands/force/org/create'
import { OrgSnapshotCreateCommand } from 'salesforce-alm/dist/commands/force/org/snapshot/create'
import { config } from "dotenv"
import { resolve } from "path"
config({ path: resolve(__dirname, "../../../../.env") })

export default class Create extends SfdxCommand {

    public static examples = ApexTestRunCommand.help;
    protected static requiresUsername = true;
    protected static supportsDevhubUsername = false;
    protected static requiresProject = true;
    protected static varargs = true;
    private conn: Connection;
    private prod: Connection;
    private prodOrg: Org;

    protected static flagsConfig: FlagsConfig = {

        name: flags.string({
            char: 'n',
            required: false,
            description: 'Name of Org to Create'
        }),

        envtype: flags.string({
            char: 'e',
            required: false,
            description: 'Type of Environment'
        }),

        verbose: flags.builtin()
    }

    public async run(): Promise<AnyJson> {

        this.prodOrg = await Org.create({ aliasOrUsername: process.env.PROD_SB_UNAME })
        this.prod = this.prodOrg.getConnection()
        this.conn = this.org.getConnection()
        await this.work()

        return process.exit(0)
    }

    private async work() {
        try {
            let type = this.flags.envtype || 'Scratchorg'
            if (type == 'Scratchorg') {
                let res: any = await this.conn.query(`Select,Id Name from ALM_Environment_C where Name='${this.flags.name}'`)
                if (res.records.length > 0) {
                    OrgCreateCommand.id = 'org:create'
                    res = await this.conn.query(`SELECT Id FROM RecordType where SobjectType = 'ALM_Environment__C' and DeveloperName='Snapshot'`)
                    let snapshotId = res.records[0].RecordType.Id
                    res = await this.conn.query(`select Name from ALM_Environment__c where RecordType.Id='${snapshotId}' and latest=true`)
                    OrgCreateCommand.run([`orgName=${this.flags.name}`, `snapshot=${res.records[0].Name}`, `username=jenkins.user@alm.pilot.${this.flags.name}`, '-a', this.flags.name, '-v', this.prod.getUsername(), '-d', '30'])
                    DataRecordUpdateCommand.id = 'force:apex:data:update'
                    await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-i', res.records[0].Id, '-v', `ALM_Status__c=Creating ALM_Username__c=jenkins.user@alm.pilot.${this.flags.name}`])
                } else {
                    this.ux.log(`There is no New Record for this ScratchOrg? Shouldn't be happening`)
                }
            } else if (type == 'Snapshot') {
                    let res : any = await this.conn.query(`select Id, ALM_Username__c from ALM_Environment_C where Name='${this.flags.name}'`)
                    OrgSnapshotCreateCommand.id = 'org:snapshot:create'
                    OrgSnapshotCreateCommand.run(['-o',res.records[0].ALM_Username__c, '-n', this.flags.name, '-d', 'Contains Deployed Classes and Test Run', '-v', this.prod.getUsername()])
                    DataRecordUpdateCommand.id = 'force:apex:data:update'
                    await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-i', res.records[0].Id, '-v', `ALM_Status__c=Creating latest=true`])
                    res = await this.conn.query(`select Id, ALM_Username__c from ALM_Environment_C where Name=!'${this.flags.name}'`)
                    for(const record of res){
                        await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-i', record.Id, '-v', `latest=false`])
                    }

            } else if (type == 'Sandbox') {
                let sandboxdef = [{
                    LicenseType: 'DEVELOPER',
                    SandboxName: this.flags.name,
                    Description: 'Created Validation Box for ALM Pilot'
                }]

                let res: any = await this.prod.tooling.sobject('SandboxInfo').create(sandboxdef)
                this.ux.log(res)

                this.ux.log(`Updating Status on ALM_Environment__c`)
                let res1: any = await this.conn.query(`Select Id from ALM_Environment__c where Name='${this.flags.name}'`)
                DataRecordUpdateCommand.id = 'force:apex:data:update'
                await DataRecordUpdateCommand.run(['-s', 'ALM_Environment__c', '-i', res1.records[0].Id, '-v', `ALM_Status__c=Creating`])
            }
        } catch (error) {
            throw new SfdxError(error.message)
        }
    }

}